import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyAppsRoutingModule } from './my-apps-routing.module';
import { MyAppsComponent } from './myapps.component';
import { FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { MessageService } from 'primeng/api';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';

@NgModule({
  declarations: [MyAppsComponent],
  imports: [CommonModule, MyAppsRoutingModule, FormsModule, DropdownModule, ProgressSpinnerModule, ToastModule],
  providers: [MessageService]
})
export class MyAppsModule { }
