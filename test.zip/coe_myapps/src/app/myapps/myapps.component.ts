import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { MyappsApiService } from './services/myapps-api.service';
import { MyappsSharedService } from './services/myapps-shared.service';

@Component({
  selector: 'app-myapps',
  templateUrl: './myapps.component.html',
  styleUrls: ['./myapps.component.css']
})
export class MyAppsComponent implements OnInit {
  searchInput = '';
  selectedCategory = '';
  categOptions = [
    { name: 'All Apps', value: '' },
    { name: 'Medicare', value: 'Medicare' },
    { name: 'Medicaid', value: 'Medicaid' },
    { name: 'WGS', value: 'WGS' }
  ];
  apps = [
    {
      appname: 'JCode',
      bot_name: 'JCODE',
      name: 'jcode',
      icon: 'icon_jcode',
      category: ['Medicaid'],
      app_description:
        'To provide pricing as per guidelines to ensure accurate and  timely processing of claims submited with NOC timely processing of claims submited with NOC ',
      app_health: true,
      accuracy: '92.33%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'Medicare Multiline Co-ordination Processing (MMCP)',
      bot_name: 'MMCP',
      name: 'mmcp',
      icon: 'icon_mmcp',
      category: ['WGS'],
      app_description:
        'It’s an assisting tool. After checking the allowable and Medicare paid, patient responsibilities amount calculate',
      app_health: true,
      accuracy: '98%',
      downtime: '10 hrs.',
      runs_in_progress: 2
    },
    {
      appname: 'Long Term Service and Support (LTSS)',
      bot_name: 'LTSS',
      name: 'ltss',
      icon: 'icon_ltss',
      category: ['WGS'],
      app_description:
        "It's an end to end tool. This tool validates and process as per Authorization, Value code, Accomodation code and Bypass code",
      app_health: true,
      accuracy: '100%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'OneClick Automation',
      bot_name: 'ONECLICK',
      name: 'oca',
      icon: 'icon_oneclick',
      category: ['Medicare'],
      app_description: 'One bot to simplify our multiple manual intervention.',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'Itemized Bill Generator',
      bot_name: 'IB',
      name: 'ib',
      icon: 'icon_ib_bot',
      category: ['Medicare', 'Medicaid'],
      app_description: 'Finding curve out for specific dates following the itemized bill.',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'ASH Claims',
      bot_name: 'ASH',
      name: 'ash',
      icon: 'icon_ashclaims',
      category: ['Medicaid'],
      app_description: 'Automate reviewing attachment to ensure fields are populated appropriately. ',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'UAT Claims Processing',
      bot_name: 'UAT',
      name: 'uat_automation',
      icon: 'icon_uat',
      category: ['Medicare'],
      app_description:
        'Each claim number follows an action to conduct a claim processing simulation. Thereafter, payment amounts for each claim will be saved and downloaded as spreadsheet. ',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'Keying Claims',
      bot_name: 'KCUA',
      name: 'kcua',
      icon: 'icon_kcua',
      category: ['Medicare'],
      app_description: 'To automate Keying Claims',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'DCE Audits',
      bot_name: 'DCE',
      name: 'dce',
      icon: 'icon_dce',
      category: ['Medicare'],
      app_description:
        'Digital Claims Examiner (DCE) is an AI based that takes a predictive approach to successfully match an authorization to the claim. Once the claim has a successful auth match then Pega adjudicates the claim. Although error rate has been low, auditing DCE is infrequent because of resource constraints.',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'Repair Management',
      bot_name: 'RMA',
      name: 'repairManagement',
      icon: 'icon_rma',
      category: ['Medicare'],
      app_description: 'To automate Repair Management.',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'Encounters Automation',
      bot_name: 'ECA',
      name: 'eca',
      icon: 'icon_eca',
      category: ['Medicare'],
      app_description: 'To automate the merge of Claim File and Encounter File.',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'Claims Consolidation',
      bot_name: 'CC',
      name: 'cc',
      icon: 'icon_cc',
      category: ['Medicare'],
      app_description: 'To automate Claims Consolidation.',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'Med Sup Letter Automation',
      bot_name: 'Medsup',
      name: 'Medsup',
      icon: 'icon_medsup',
      category: ['Medicare'],
      app_description: 'Automate reviewing attachment to ensure fields are populated appropriately.',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'Macro Automation',
      bot_name: 'macro',
      name: 'macro',
      icon: 'icon_macro',
      category: ['Medicare'],
      app_description:
        'Real-time VM Monitoring dashboard to optimize and channelize the Virtual machines to run Macro applications effectively.',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    },
    {
      appname: 'PCP Form',
      bot_name: 'PCP',
      name: 'PCP',
      icon: 'icon_cc',
      category: ['Medicare'],
      app_description: 'This bot extract the data from both pdf and html.',
      app_health: true,
      accuracy: '98%',
      downtime: '30 sec.',
      runs_in_progress: 2
    }
    // {
    //   appname: 'ITS',
    //   bot_name: 'its',
    //   name: 'its',
    //   icon: 'icon_its',
    //   category: ['Medicare'],
    //   app_description: 'Identify WGS Sterilization claims with missing or incomplete Consent Forms.',
    //   app_health: true,
    //   accuracy: '98%',
    //   downtime: '30 sec.',
    //   runs_in_progress: 2
    // }
  ];

  availableApps: any[] = [];
  categorisedApps: any[] = [];
  filteredApps: any[] = [];

  loading: boolean = false;

  constructor(
    private router: Router,
    private myappsApiService: MyappsApiService,
    private messageService: MessageService,
    private myappsSharedService: MyappsSharedService
  ) {}

  ngOnInit(): void {
    this.myappsSharedService.getLoading().subscribe((val) => {
      this.loading = val;
    });
    this.myappsSharedService.setLoading(true);

    this.myappsApiService.getMyappsData().subscribe({
      next: (res: any) => {
        this.myappsSharedService.setLoading(false);
        this.availableApps = this.apps
          .filter((x: any) => res.assigned_bots.map((i: any) => i.bot_name)?.indexOf(x.bot_name) != -1)
          .map((e) => ({
            ...e,
            app_description: res.assigned_bots
              .filter((j: any) => j.bot_name === e.bot_name)
              .map((i: any) => i.description)[0]
          }))
          .sort((obj1, obj2) => obj1.bot_name.toLowerCase().localeCompare(obj2.bot_name.toLowerCase()));

        this.categorisedApps = [...this.availableApps];
        this.filteredApps = [...this.availableApps];
      },
      error: (err: any) => {
        this.myappsSharedService.setLoading(false);
        this.messageService.add({ sticky: true, severity: 'error', summary: 'something went wrong' });
      }
    });
  }

  openApp(name: string) {
    this.router.navigate([`/${name}`]);
  }

  changeInSearchInput() {
    this.filteredApps = this.categorisedApps.filter((x) => {
      return x.appname.toLowerCase().includes(this.searchInput.toLowerCase());
    });
  }

  ChangeInAppCategory() {
    if (this.selectedCategory == '') {
      this.categorisedApps = this.availableApps;
    } else {
      this.categorisedApps = [...this.availableApps.filter((x) => x.category?.indexOf(this.selectedCategory) != -1)];
    }
    this.changeInSearchInput();
  }
}
