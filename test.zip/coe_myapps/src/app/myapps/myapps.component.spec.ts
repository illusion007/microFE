import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { MyAppsComponent } from './myapps.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('MyAppsComponent', () => {
  let component: MyAppsComponent;
  let fixture: ComponentFixture<MyAppsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],  //FormsModule
      declarations: [MyAppsComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(MyAppsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should filter apps correctly when searched with a proper keyword and with an uppercase input', () => {
    component.searchInput = 'JCO';    //instead can we set the value to HTML input field directly
    component.changeInSearchInput();
    expect(component.filteredApps.length).toEqual(1);
    expect(component.filteredApps[0].appname).toEqual('JCode'); 
  });

  it('should filter apps correctly when searched with a proper keyword and with a lowercase input', () => {
    component.searchInput = 'te'
    component.changeInSearchInput();
    expect(component.filteredApps.length).toEqual(2);  //if filtered claims length greater than 1, check all filtered values are correct or not
  })

  it('should not show any apps when searched with an improper keyword', () => {
    component.searchInput = 'xD';
    component.changeInSearchInput();
    expect(component.filteredApps.length).toEqual(0);
  })

  it('should filter out All Apps if All Apps is selected as the filter category', () => {
    spyOn(component, 'changeInSearchInput').and.callThrough();
    component.selectedCategory = '';
    component.ChangeInAppCategory();
    expect(component.categorisedApps.length).toEqual(component.apps.length);
    expect(component.changeInSearchInput).toHaveBeenCalledTimes(1);
    expect(component.categorisedApps).toEqual(component.filteredApps);
  })

  it('should filter out WGS apps if WGS is selected as the filter category', () => {
    spyOn(component, 'changeInSearchInput').and.callThrough();
    component.selectedCategory = 'WGS';
    component.ChangeInAppCategory();
    expect(component.categorisedApps.length).toEqual(2);
    expect(component.changeInSearchInput).toHaveBeenCalledTimes(1);
    expect(component.categorisedApps).toEqual(component.filteredApps);
  })

  it('should filter out Medicare apps if Medicare is selected as the filter category', () => {
    spyOn(component, 'changeInSearchInput').and.callThrough();
    component.selectedCategory = 'Medicare';
    component.ChangeInAppCategory();
    expect(component.categorisedApps.length).toEqual(3);
    expect(component.changeInSearchInput).toHaveBeenCalledTimes(1);
    expect(component.categorisedApps).toEqual(component.filteredApps);
  })

  it('should run the Oneclick Automation app on clicking the start app button for Oneclick Automation', () => {
    spyOn(component, 'openApp').and.callThrough();
    let ocaButton = fixture.debugElement.nativeElement.querySelector('.app-card:nth-child(4) .start-app button');
    ocaButton.click();
    expect(component.openApp).toHaveBeenCalledOnceWith('oca');
  })
});
