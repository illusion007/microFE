import { TestBed } from '@angular/core/testing';

import { MyappsApiService } from './myapps-api.service';

describe('MyappsApiService', () => {
  let service: MyappsApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MyappsApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
