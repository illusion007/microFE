import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class MyappsApiService {

  url = environment.serverUrl + 'bot_marketplace/myapps/';
  private key: string;
  private headers: HttpHeaders;

  constructor(private http: HttpClient) {
    this.key = '000102030405060708090a0b0c0d0e0f';
    const decrypted = CryptoJS.AES.decrypt(localStorage.getItem('token') || '', this.key).toString(CryptoJS.enc.Utf8);
    this.headers = new HttpHeaders().append('Authorization', JSON.parse(JSON.stringify(decrypted)));
  }

  getMyappsData() {
    return this.http.get(this.url, { headers: this.headers });
  }
}
