import { TestBed } from '@angular/core/testing';

import { MyappsSharedService } from './myapps-shared.service';

describe('MyappsSharedService', () => {
  let service: MyappsSharedService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MyappsSharedService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
