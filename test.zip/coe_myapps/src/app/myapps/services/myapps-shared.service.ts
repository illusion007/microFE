import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyappsSharedService {

  private loadingSubject: BehaviorSubject<boolean>;

  constructor() {
    this.loadingSubject = new BehaviorSubject<boolean>(false);
  }

  public setLoading(val: boolean) {
    this.loadingSubject.next(val);
  }

  public getLoading() {
    return this.loadingSubject.asObservable();
  }

}
