export const environment = {
  production: true,
  serverUrl: 'http://va33dlvjre309:8000/'
  // serverUrl:'http://10.45.35.118:8000/'
};
