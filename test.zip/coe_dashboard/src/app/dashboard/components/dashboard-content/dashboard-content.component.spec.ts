import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BehaviorSubject, of } from 'rxjs';
import { DashboardComponent } from '../../dashboard.component';
import { DashboardSharedService } from '../../services/dashboard-shared.service';

import { DashboardContentComponent } from './dashboard-content.component';

describe('DashboardContentComponent', () => {
  let component: DashboardContentComponent;
  let fixture: ComponentFixture<DashboardContentComponent>;

  let res = 
  {
    "Success": true,
    "role": "ADMIN",
    "ag_id": "AL06653",
    "user_name": "Varshney, Aman",
    "rangeDates": [new Date(), new Date()],
    "total_stat": {
        "total_claims": 118,
        "total_success": 3,
        "total_failure": 115
    },
    "weekly_stat": {
        "label": [
            "2023-01-07",
            "2023-01-08",
            "2023-01-09",
            "2023-01-10"
        ],
        "success": [
            0,
            0,
            3,
            0
        ],
        "fail": [
            0,
            0,
            115,
            0
        ]
    },
    "apps": [
        [
            {
                "data": [
                    3,
                    99
                ],
                "percentage": 2.941176470588235,
                "borderColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "backgroundColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "hoverBackgroundColor": [
                    "#30bdc7",
                    "#152f70"
                ],
                "hoverBorderColor": [
                    "#fff",
                    "#fff"
                ],
                "app": "WGS-MMCP"
            }
        ],
        [
            {
                "data": [
                    0,
                    16
                ],
                "percentage": 0.0,
                "borderColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "backgroundColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "hoverBackgroundColor": [
                    "#30bdc7",
                    "#152f70"
                ],
                "hoverBorderColor": [
                    "#fff",
                    "#fff"
                ],
                "app": "UAT AUTOMATION"
            }
        ]
    ]
  }

  let dbs: DashboardSharedService;

  beforeEach(async () => {

    // dashboardSharedSpy = jasmine.createSpyObj<DashboardSharedService>('DashboardSharedService', {
    //     getResponse: of(res),
    //     getDataAvailable: of(true),
    //     getNoDataMessage: of(""),
    //     setLoading: undefined,
    //     // setDataAvailable: undefined
    // })
    

    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [ DashboardContentComponent, DashboardComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ],
      providers: [ DashboardSharedService ]
    })
    .compileComponents();

    dbs = TestBed.inject(DashboardSharedService);
    dbs.setResponse(res);
    dbs.setDataAvailable(true);
    dbs.setNoDataMessage('');

    fixture = TestBed.createComponent(DashboardContentComponent);
    component = fixture.componentInstance;

    component.display = true;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    component.exportExcel();
  });

  it('should fill the chart data properly according to te response received.', () => {
      expect(component.totalClaims).toEqual(res.total_stat.total_claims);
      expect(component.failureCount).toEqual(res.total_stat.total_failure);
      expect(component.successCount).toEqual(res.total_stat.total_success);
      expect(component.fromDate).toEqual(res.rangeDates[0]);
      expect(component.toDate).toEqual(res.rangeDates[1]);
      dbs.getDataAvailable().subscribe(val => {
          expect(val).toBeTrue();
      })
  });


  it('should display noDataAvailable message.', () => {
      let mockRes = {
        "Success": true,
        "role": "ADMIN",
        "ag_id": "AL06653",
        "user_name": "Varshney, Aman",
        "rangeDates": [new Date(), new Date()],
        "Message": "No records found"
      }
      dbs.setResponse(mockRes);
      component.getChartData();
      dbs.getDataAvailable().subscribe(val => {
          expect(val).toBeFalse();
      })
  })

  
  it('should export the processed excel file and get ready for download', () => {
    spyOn(component, 'exportExcel').and.callThrough();
    let button = fixture.debugElement.nativeElement.querySelector('.download');
    button.click();
    expect(component.exportExcel).toHaveBeenCalled();
  });

});
