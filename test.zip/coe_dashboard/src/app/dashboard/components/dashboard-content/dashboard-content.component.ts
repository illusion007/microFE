import { Component, OnInit } from '@angular/core';
import { ChartConfiguration } from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import * as saveAs from 'file-saver';
import { DashboardSharedService } from '../../services/dashboard-shared.service';
@Component({
  selector: 'app-dashboard-content',
  templateUrl: './dashboard-content.component.html',
  styleUrls: ['./dashboard-content.component.css']
})
export class DashboardContentComponent implements OnInit {
  public barChartLegend = true;
  public barChartPlugins = [ChartDataLabels];

  fromDate = new Date();
  toDate = new Date();

  successData: any[] = [];
  exceptionData: any[] = [];
  labelsArray: any[] = [];
  apps: any[] = [];
  totalClaims = 0;
  successCount = 0;
  failureCount = 0;

  response: any;
  display: boolean = false;

  public barChartData: any = {};

  public barChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: true,
    scales: {
      x: {
        display: true,
        grid: {
          display: false
        },
        title: {
          display: true,
          text: 'Date',
          color: '#000000',
          font: {
            family: 'Arial'
          }
        },
        ticks: {
          padding: 15
        }
      },
      y: {
        display: true,
        grid: {
          display: true
        },
        title: {
          display: true,
          text: 'Count',
          color: '#',
          font: {
            family: 'Arial'
          }
        }
      }
    }
  };

  //   apps=[[
  //     { data: [ 350, 450],
  //       borderColor: ["#46c2cb", "#20376F"],
  //       backgroundColor: ["#46c2cb", "#20376F"],
  //       hoverBackgroundColor:["#30bdc7", "#152f70"],
  //       hoverBorderColor: ["#fff", "#fff"],
  //     app:'mmcp'}
  //   ],[
  //     { data: [ 120, 450],
  //       borderColor: ["#46c2cb", "#20376F"],
  //       backgroundColor: ["#46c2cb", "#20376F"],
  //       hoverBackgroundColor:["#30bdc7", "#152f70"],
  //       hoverBorderColor: ["#fff", "#fff"],
  //     app:'mmcp'}
  //   ],
  //   [
  //     { data: [ 32350, 23450],
  //       borderColor: ["#46c2cb", "#20376F"],
  //       backgroundColor: ["#46c2cb", "#20376F"],
  //       hoverBackgroundColor:["#30bdc7", "#152f70"],
  //       hoverBorderColor: ["#fff", "#fff"],
  //     app:'mmcp'}
  //   ],
  //   [
  //     { data: [ 3250, 4150],
  //       borderColor: ["#46c2cb", "#20376F"],
  //       backgroundColor: ["#46c2cb", "#20376F"],
  //       hoverBackgroundColor:["#30bdc7", "#152f70"],
  //       hoverBorderColor: ["#fff", "#fff"],
  //     app:'mmcp'}
  //   ],
  //   [
  //     { data: [ 1350, 450],
  //       borderColor: ["#46c2cb", "#20376F"],
  //       backgroundColor: ["#46c2cb", "#20376F"],
  //       hoverBackgroundColor:["#30bdc7", "#152f70"],
  //       hoverBorderColor: ["#fff", "#fff"],
  //     app:'mmcp'}
  //   ],
  //   [
  //     { data: [ 3540, 2450],
  //       borderColor: ["#46c2cb", "#20376F"],
  //       backgroundColor: ["#46c2cb", "#20376F"],
  //       hoverBackgroundColor:["#30bdc7", "#152f70"],
  //       hoverBorderColor: ["#fff", "#fff"],
  //     app:'mmcp'}
  //   ],
  //   [
  //     { data: [ 3540, 2450],
  //       borderColor: ["#46c2cb", "#20376F"],
  //       backgroundColor: ["#46c2cb", "#20376F"],
  //       hoverBackgroundColor:["#30bdc7", "#152f70"],
  //       hoverBorderColor: ["#fff", "#fff"],
  //     app:'mmcp'}
  //   ],
  //   [
  //     { data: [ 3540, 2450],
  //       borderColor: ["#46c2cb", "#20376F"],
  //       backgroundColor: ["#46c2cb", "#20376F"],
  //       hoverBackgroundColor:["#30bdc7", "#152f70"],
  //       hoverBorderColor: ["#fff", "#fff"],
  //     app:'mmcp'}
  //   ],
  //   [
  //     { data: [ 3540, 2450],
  //       borderColor: ["#46c2cb", "#20376F"],
  //       backgroundColor: ["#46c2cb", "#20376F"],
  //       hoverBackgroundColor:["#30bdc7", "#152f70"],
  //       hoverBorderColor: ["#fff", "#fff"],
  //     app:'mmcp'}
  //   ]
  // ]


  public doughnutChartOptions = {
    responsive: false,
    plugins: {
      datalabels: { display: false },
      tooltip: {
        enabled: false
      },
      hover: { mode: null }
    }
  }

  public doughnutChartLabels: string[] = ['Processed Claims', 'Exception Claims'];

  dataAvailable: boolean = true;
  noDataMessage = '';

  constructor(private dashboardSharedService: DashboardSharedService) {

    this.dashboardSharedService.getDataAvailable().subscribe(val => this.dataAvailable = val);
    this.dashboardSharedService.getNoDataMessage().subscribe(msg => this.noDataMessage = msg);
  }

  ngOnInit(): void {
    this.display = false;
    this.getChartData();
  }

  getChartData() {
    this.dashboardSharedService.setLoading(true);
    this.dashboardSharedService.getResponse().subscribe(
      (res: any) => {
        this.fromDate = res.rangeDates[0];
        this.toDate = res.rangeDates[1];
        if (res.Message) {
          this.dashboardSharedService.setDataAvailable(false);
        } else {
          this.dashboardSharedService.setDataAvailable(true);
          this.totalClaims = res.total_stat.total_claims;
          this.successCount = res.total_stat.total_success;
          this.failureCount = res.total_stat.total_failure;

          this.labelsArray = res.weekly_stat.label;
          this.successData = res.weekly_stat.success;
          this.exceptionData = res.weekly_stat.fail;
          this.apps = res.apps;

          this.barChartData = {
            labels: this.labelsArray,
            datasets: [
              {
                data: this.successData, label: 'Success', stack: 'a', datalabels: {
                  anchor: 'end',
                  align: 'bottom',
                  color: 'black',
                },
                borderColor: '#fff',
                backgroundColor: '#83c7cc',
                hoverBackgroundColor: '#83c7cc',
                hoverBorderColor: '#fff'
              },
              {
                data: this.exceptionData, label: 'Exceptions', stack: 'a', datalabels: {
                  anchor: 'end',
                  align: 'bottom',
                  color: '#E2E2E2'
                },
                borderColor: '#fff',
                backgroundColor: '#20376F',
                hoverBackgroundColor: '#20376F',
                hoverBorderColor: '#fff'
              }
            ]
          }
          this.response = res;
        }

        
        this.dashboardSharedService.setLoading(false);
        this.display = true;
      }
    )
  }

  exportExcel() {
    this.dashboardSharedService.setLoading(true);
    let sheet1 = this.response.apps.map((x: any) => {
      return { "App Name": x[0].app, "Processed": x[0].data[0], "Exceptions": x[0].data[1], "Total": x[0].data[0] + x[0].data[1] };
    });
    let sheet2: Object[] = [];
    let dateArray = this.response.weekly_stat.label;
    let successArray = this.response.weekly_stat.success;
    let failureArray = this.response.weekly_stat.fail;
    for (let i = 0; i < dateArray.length; i++) {
      sheet2.push({
        "Date": dateArray[i],
        "Processed": successArray[i],
        "Exceptions": failureArray[i],
        "Total": successArray[i] + failureArray[i]
      });
    };
    import("xlsx").then(xlsx => {
      const worksheet1 = xlsx.utils.json_to_sheet(sheet1);
      const worksheet2 = xlsx.utils.json_to_sheet(sheet2);
      const workbook = { Sheets: { 'Bot Status': worksheet1, 'Date Wise Details': worksheet2 }, SheetNames: ['Bot Status', 'Date Wise Details'] };
      const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
      if (this.response.userSearch) {
        this.saveAsExcelFile(excelBuffer, `report_${this.response.ag_id}_${new Date().getTime()}`);
      } else {
        this.saveAsExcelFile(excelBuffer, `report_admin_${new Date().getTime()}`);
      }
    });
    this.dashboardSharedService.setLoading(false);
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE =
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE,
    });
    saveAs(
      data,
      fileName + EXCEL_EXTENSION
    );
  }

}
