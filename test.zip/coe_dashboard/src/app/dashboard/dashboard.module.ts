import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { MessageService } from 'primeng/api';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { HttpClientModule } from '@angular/common/http';
import { DashboardContentComponent } from './components/dashboard-content/dashboard-content.component';
import { NgChartsModule } from 'ng2-charts';
import { CalendarModule } from 'primeng/calendar';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { FormsModule } from '@angular/forms';
import { dashboardApiService } from './services/dashboard-api.service';
@NgModule({
  declarations: [DashboardComponent, DashboardContentComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    HttpClientModule,
    ProgressSpinnerModule,
    ToastModule,
    FormsModule,
    NgChartsModule,
    CalendarModule,
    OverlayPanelModule,
    AutoCompleteModule
  ],
  providers: [MessageService],
})
export class DashboardModule {}
