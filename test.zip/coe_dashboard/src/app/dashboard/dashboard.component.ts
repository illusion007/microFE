import { Component, OnInit } from '@angular/core';
import { dashboardApiService } from './services/dashboard-api.service';
import { MessageService } from 'primeng/api';
import { DashboardSharedService } from './services/dashboard-shared.service';
import { catchError, forkJoin, of, throwError } from 'rxjs';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  loading: boolean = false;
  searchUser: boolean = false;
  username: any;
  user_role: any;
  rangeDates: Date[] = [];
  user_rangeDates: Date[] = [];
  fromDate = new Date();
  toDate = new Date();
  user_fromDate = new Date();
  user_toDate = new Date();
  minDate: Date = new Date();
  maxDate = new Date();
  userId = '';
  user_search_astersik = {
    color: '#e20a0a',
    'font-size': '16px'
  };
  searched_user_name: any;
  searched_user_id: any;
  searched_user_initials: any;
  isAdmin = false;

  fetchDashboardContent = true;

  userNames: any = [];
  filteredUsernames: any = [];
  selectedUser = '';
  constructor(
    private dashboardApiService: dashboardApiService,
    private dashboardSharedService: DashboardSharedService,
    private messageService: MessageService
  ) {
    this.dashboardSharedService.getLoading().subscribe((val) => {
      this.loading = val;
    });
  }

  ngOnInit(): void {
    this.rangeDates = [this.getLastNthDate(7), new Date()];
    this.user_rangeDates = [this.getLastNthDate(7), new Date()];
    this.fromDate = this.rangeDates[0];
    this.toDate = this.rangeDates[1] || this.rangeDates[0];
    this.minDate = this.getLastNthDate(14);

    this.dashboardSharedService.setLoading(true);

    if (!this.rangeDates[1]) {
      this.rangeDates[1] = this.rangeDates[0];
    }

    const dashboardDataCall = this.dashboardApiService
      .getUserData(this.rangeDates[0].toString(), this.rangeDates[1].toString(), '')
      .pipe(
        catchError((err) => {
          this.handleFetchDashboardError(err);
          return of(err);
        })
      );

    const userListCall = this.dashboardApiService.getUsersList().pipe(
      catchError((err) => {
        this.messageService.add({ sticky: true, severity: 'error', summary: 'Unable to get User List' });
        return of(err);
      })
    );

    forkJoin([dashboardDataCall, userListCall]).subscribe(([dashboardData, userListData]) => {
      this.dashboardSharedService.setLoading(false);
      let dashboardRes: any = dashboardData;
      if (!dashboardRes.error) this.AfterFetchDashboardApi(dashboardRes);
      if (!userListData.error) {
        let userListRes: any = userListData;
        if (userListRes.Success) this.userNames = userListRes.data;
        else this.messageService.add({ sticky: true, severity: 'error', summary: userListRes.Message });
      }
    });
  }

  showOverlay() {
    let box = document.getElementById('overlay-box') as HTMLElement;
    if (box.style.display === 'none') {
      box.style.display = 'block';
    }
  }

  closeOverlay() {
    let box = document.getElementById('overlay-box') as HTMLElement;
    if (box && !(box.style.display === 'none')) {
      box.style.display = 'none';
    }
    this.user_rangeDates = [this.getLastNthDate(7), new Date()];
    this.userId = '';
    this.selectedUser = '';
  }

  filterUsernames(event: any) {
    let filtered: any[] = [];
    let query = event.query;
    this.userNames
      .filter(
        (user: any) =>
          user.username.toLowerCase().includes(query.toLowerCase()) ||
          user.user_id.toLowerCase().startsWith(query.toLowerCase())
      )
      .map((user: any) => filtered.push(user.username + '- ' + user.user_id));
    this.filteredUsernames = filtered;
  }

  selectUser(event: any) {
    this.selectedUser = event;
  }

  getLastNthDate(n: any) {
    let today = new Date();
    let month = today.getMonth();
    let year = today.getFullYear();
    let prevdate = today.getDate() - n;
    let prevMonth;
    if (today.getDate() - n < 1) {
      prevdate = new Date(year, month - 1, 0).getDate() + (today.getDate() - n);
      prevMonth = month === 0 ? 11 : month - 1;
    } else {
      prevMonth = month;
    }
    let prevYear = prevMonth === 11 ? year - 1 : year;

    let returnDate = new Date();
    returnDate.setMonth(prevMonth);
    returnDate.setFullYear(prevYear);
    returnDate.setDate(prevdate);
    return returnDate;
  }

  fetchDashboardDetails() {
    this.dashboardSharedService.setLoading(true);
    if (!this.rangeDates[1]) {
      this.rangeDates[1] = this.rangeDates[0];
    }
    this.dashboardApiService.getUserData(this.rangeDates[0].toString(), this.rangeDates[1].toString(), '').subscribe({
      next: (res: any) => {
        this.AfterFetchDashboardApi(res);
      },
      error: (err) => {
        this.handleFetchDashboardError(err);
      }
    });
    let box = document.getElementById('overlay-box') as HTMLElement;
    if (box) {
      this.closeOverlay();
    }
  }

  AfterFetchDashboardApi(res: any) {
    if (res.Success) {
      if (res.Message) {
        this.dashboardSharedService.setNoDataMessage(res.Message);
      }
      res.rangeDates = this.rangeDates;
      this.dashboardSharedService.setResponse(res);
      this.fetchDashboardContent = true;
      if (res.role == 'ADMIN') {
        this.isAdmin = true;
      }
      this.username = res.user_name;
    } else {
      this.fetchDashboardContent = false;
      this.messageService.add({ sticky: true, severity: 'error', summary: res.Message });
    }
    this.dashboardSharedService.setLoading(false);
  }

  handleFetchDashboardError(err: any) {
    this.dashboardSharedService.setLoading(false);
    this.fetchDashboardContent = false;
    this.messageService.add({ sticky: true, severity: 'error', summary: 'something went wrong' });
  }

  fetchUser() {
    if (!this.isAdmin) {
      return;
    }
    if (!this.userId) {
      this.messageService.add({ sticky: true, severity: 'error', summary: 'UserID cannot be an empty field.' });
      return;
    }

    if (!this.selectedUser || this.selectedUser != this.userId) {
      this.messageService.add({ sticky: true, severity: 'error', summary: 'Please select a valid user.' });
      return;
    }
    this.dashboardSharedService.setLoading(true);
    let searched_user = '';
    if (this.userId.split('- ').length == 2) searched_user = this.userId.split('- ')[1];
    else searched_user = this.userId;

    if (!this.user_rangeDates[1]) {
      this.user_rangeDates[1] = this.user_rangeDates[0];
    }
    this.dashboardApiService
      .getUserData(this.user_rangeDates[0].toString(), this.user_rangeDates[1].toString(), searched_user.toUpperCase())
      .subscribe({
        next: (res: any) => {
          this.dashboardSharedService.setLoading(false);
          if (res.Success) {
            if (res.Message) {
              this.dashboardSharedService.setNoDataMessage(res.Message);
            }
            const dates = this.user_rangeDates;
            res.rangeDates = dates;
            res.userSearch = true;
            this.fetchDashboardContent = true;
            this.dashboardSharedService.setResponse(res);
            if (res.user_name) {
              this.searched_user_name = res.user_name;
              let name = res.user_name.split(', ');
              this.searched_user_initials = name[0][0] + name[name.length - 1][0];
            }
            this.searched_user_id = res.ag_id ? res.ag_id : '';
            this.searchUser = true;
          } else {
            this.messageService.add({ sticky: true, severity: 'error', summary: res.Message });
          }
          this.closeOverlay();
        },
        error: (err) => {
          this.dashboardSharedService.setLoading(false);
          this.fetchDashboardContent = false;
          this.messageService.add({ sticky: true, severity: 'error', summary: 'something went wrong' });
          this.closeOverlay();
        }
      });
  }

  setUserSearch() {
    this.rangeDates = [this.getLastNthDate(7), new Date()];
    this.fetchDashboardDetails();
    this.searchUser = false;
  }
}
