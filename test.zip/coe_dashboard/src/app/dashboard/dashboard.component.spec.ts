import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { MessageService } from 'primeng/api';
import { CalendarModule } from 'primeng/calendar';
import { of, throwError } from 'rxjs';

import { DashboardComponent } from './dashboard.component';
import { dashboardApiService } from './services/dashboard-api.service';
import { DashboardSharedService } from './services/dashboard-shared.service';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;

  let res = 
{
    "Success": true,
    "role": "ADMIN",
    "ag_id": "AL06625",
    "user_name": "Varshney, Aman",
    "total_stat": {
        "total_claims": 118,
        "total_success": 3,
        "total_failure": 115
    },
    "weekly_stat": {
        "label": [
            "2023-01-07",
            "2023-01-08",
            "2023-01-09",
            "2023-01-10"
        ],
        "success": [
            0,
            0,
            3,
            0
        ],
        "fail": [
            0,
            0,
            115,
            0
        ]
    },
    "apps": [
        [
            {
                "pieChartData": [
                    3,
                    99
                ],
                "percentage": 2.941176470588235,
                "borderColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "backgroundColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "hoverBackgroundColor": [
                    "#30bdc7",
                    "#152f70"
                ],
                "hoverBorderColor": [
                    "#fff",
                    "#fff"
                ],
                "app": "WGS-MMCP"
            }
        ],
        [
            {
                "pieChartData": [
                    0,
                    16
                ],
                "percentage": 0.0,
                "borderColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "backgroundColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "hoverBackgroundColor": [
                    "#30bdc7",
                    "#152f70"
                ],
                "hoverBorderColor": [
                    "#fff",
                    "#fff"
                ],
                "app": "UAT AUTOMATION"
            }
        ]
    ]
  }
  let dashboardApiSpy !: any;

  beforeEach(async () => {

    dashboardApiSpy = jasmine.createSpyObj('DashboardApiService', ['getUserData']);
    dashboardApiSpy.getUserData.and.returnValue(of(res));

    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule, CalendarModule],
      declarations: [ DashboardComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA ],
      providers: [
        MessageService, 
        {provide: dashboardApiService, useValue: dashboardApiSpy}, 
        DashboardSharedService
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    component.userId = 'AL06653';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open overlay to search for a user.', () => {
    spyOn(component, 'showOverlay').and.callThrough();
    let elem = fixture.debugElement.nativeElement.querySelector('#overlay-box');
    expect(elem.style.display).toEqual('none');
    let button = fixture.debugElement.nativeElement.querySelector('#search-box');
    button.click();
    expect(component.showOverlay).toHaveBeenCalledTimes(1)
    elem = fixture.debugElement.nativeElement.querySelector('#overlay-box');
    expect(elem.style.display).toEqual('block');
  });

  it('should close the overlay on clicking cancel button.', () => {
    let button = fixture.debugElement.nativeElement.querySelector('#search-box');
    button.click();
    
    let elem = fixture.debugElement.nativeElement.querySelector('#overlay-box');
    expect(elem.style.display).toEqual('block');

    spyOn(component, 'closeOverlay').and.callThrough();
    let cancelButton = fixture.debugElement.nativeElement.querySelector('.cancel-btn');
    cancelButton.click();
    expect(component.closeOverlay).toHaveBeenCalledTimes(1);
    elem = fixture.debugElement.nativeElement.querySelector('#overlay-box');
    expect(elem.style.display).toEqual('none');
  })

  it('should run fetchDashboardDetails with default date range.', () => {
    spyOn(component, 'fetchDashboardDetails').and.callThrough();
    component.fetchDashboardDetails();
    expect(component.toDate.toLocaleDateString().toString()).toEqual(new Date().toLocaleDateString().toString());
    expect(component.fetchDashboardDetails).toHaveBeenCalledTimes(1);
  })

  it('should fill toDate if only a single date is entered by user.', () => {
    component.rangeDates = [new Date()];
    expect(component.rangeDates.length).toEqual(1);
    spyOn(component, 'fetchDashboardDetails').and.callThrough();
    component.fetchDashboardDetails();
    expect(component.rangeDates.length).toEqual(2);
  })

  it('should set noDataMessage if no data is present.', () => {
    spyOn(DashboardSharedService.prototype, 'setNoDataMessage').and.callThrough();
    const noDataResponse = {
      "Success": true,
      "role": "ADMIN",
      "ag_id": "AL06653",
      "user_name": "Varshney, Aman",
      "Message": "No Records Found"
    };
    dashboardApiSpy.getUserData.and.returnValue(of(noDataResponse));
    component.ngOnInit();
    expect(DashboardSharedService.prototype.setNoDataMessage).toHaveBeenCalledWith(noDataResponse.Message);
  });

  it('should show toast message if response receives an error message.', () => {
    spyOn(MessageService.prototype, 'add');
    const successFalseRes = {
      "Success": false,
      "Message": "Error occured"
    };
    dashboardApiSpy.getUserData.and.returnValue(of(successFalseRes));
    component.ngOnInit();
    expect(component.fetchDashboardContent).toBeFalsy();
    expect(MessageService.prototype.add).toHaveBeenCalledTimes(1);
  })

  it('should handle error if any error is received in api call', () => {
    spyOn(MessageService.prototype, 'add');
    const err = new HttpErrorResponse({
      error:{code:400,message:"error"},
      status:400,
      statusText:'Bad Request'
    });
    dashboardApiSpy.getUserData.and.returnValue(throwError(err));
    component.ngOnInit();
    expect(component.fetchDashboardContent).toBeFalsy();
    expect(MessageService.prototype.add).toHaveBeenCalledTimes(1);
  });

  it('should show searchUser option only if the loggedIn user is an admin', () => {
    fixture.debugElement.nativeElement.querySelector('.options');
    expect(fixture.debugElement.query(By.css('.options'))).toBeDefined();
    component.isAdmin = false;
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css('.options'))).toBeNull();
  })

  //fetchUser
  it('should run fetchUser when search employee button is clicked.', () => {
    spyOn(component, 'fetchUser');
    let searchButton = fixture.debugElement.nativeElement.querySelector('.search-btn');
    searchButton.click();
    expect(component.fetchUser).toHaveBeenCalledTimes(1);
  })

  it('should return from fetchUser if the user is not an admin.', () => {
    spyOn(component, 'fetchUser').and.callThrough();
    let searchButton = fixture.debugElement.nativeElement.querySelector('.search-btn');
    component.isAdmin = false;
    searchButton.click();
    expect(component.fetchUser).toHaveBeenCalledTimes(1);
  });

  it('should return and display toast from fetchUser if the searched userID is null.', () => {
    spyOn(MessageService.prototype, 'add');
    component.userId = '';
    let searchButton = fixture.debugElement.nativeElement.querySelector('.search-btn');
    searchButton.click();
    expect(MessageService.prototype.add).toHaveBeenCalledTimes(1);
  });

  it('should autofill end date if only a single date is selected by the user.', () => {
    component.user_rangeDates = [new Date()];
    component.fetchUser();
    expect(component.user_rangeDates.length).toEqual(2);
  })

  it('should fetch data for the searched user, and set noDataMessage if no data is available for the user.', () => {
    spyOn(DashboardSharedService.prototype, 'setNoDataMessage').and.callThrough();
    spyOn(DashboardSharedService.prototype, 'getNoDataMessage').and.callThrough();
    const noDataResponse = {
      "Success": true,
      "role": "ADMIN",
      "ag_id": "AL06653",
      "user_name": "Varshney, Aman",
      "Message": "No Records Found"
    };
    dashboardApiSpy.getUserData.and.returnValue(of(noDataResponse));
    component.fetchUser();
    expect(DashboardSharedService.prototype.setNoDataMessage).toHaveBeenCalledWith(noDataResponse.Message);
    expect(component.searchUser).toBeTrue();
    expect(component.searched_user_initials).toEqual('VA');
  })

  it('should set searched_user_id to empty string if no response for ag id is received.', () => {
    const mockResponse = {
      "Success": true,
      "role": "ADMIN",
      "user_name": "Varshney, Aman",
      "Message": "No Records Found"
    };
    dashboardApiSpy.getUserData.and.returnValue(of(mockResponse));
    component.fetchUser();
    expect(component.searched_user_id).toEqual('');
  })

  it('should show toast message if response receives an error message while searching for a user.', () => {
    spyOn(MessageService.prototype, 'add');
    const successFalseRes = {
      "Success": false,
      "Message": "Error occured"
    };
    dashboardApiSpy.getUserData.and.returnValue(of(successFalseRes));
    component.fetchUser();
    expect(component.searchUser).toBeFalsy();
    expect(MessageService.prototype.add).toHaveBeenCalledTimes(1);
  })

  it('should handle error if any error is received in api call while searching for a user.', () => {
    spyOn(MessageService.prototype, 'add');
    const err = new HttpErrorResponse({
      error:{code:400,message:"error"},
      status:400,
      statusText:'Bad Request'
    });
    dashboardApiSpy.getUserData.and.returnValue(throwError(err));
    component.fetchUser();
    expect(component.searchUser).toBeFalsy();
    expect(MessageService.prototype.add).toHaveBeenCalledTimes(1);
  });

  it('should reset rangeDates and load the dashboard again on clicking back to dashboard button.', () => {
    spyOn(component, 'fetchDashboardDetails');
    component.searchUser = true;
    fixture.detectChanges();
    const dashboardButton = fixture.debugElement.nativeElement.querySelector('.back-to-dashboard');
    dashboardButton.click();
    expect(component.searchUser).toBeFalsy();
    expect(component.fetchDashboardDetails).toHaveBeenCalledTimes(1);
  })
  
});
