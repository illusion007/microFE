import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { of } from 'rxjs';
import * as CryptoJS from 'crypto-js';
import { of } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class dashboardApiService {
  //   agid = localStorage.getItem('agid') || '';
  // headers = new HttpHeaders().append('Authorization', JSON.parse(JSON.stringify(localStorage.getItem('token')) || ''));
  // constructor(private http: HttpClient) { }

  url = environment.serverUrl + 'bot_marketplace/';

  private key: string;
  private headers: HttpHeaders;

  constructor(private http: HttpClient) {
    this.key = '000102030405060708090a0b0c0d0e0f';
    const decrypted = CryptoJS.AES.decrypt(localStorage.getItem('token') || '', this.key).toString(CryptoJS.enc.Utf8);
    this.headers = new HttpHeaders().append('Authorization', JSON.parse(JSON.stringify(decrypted)));
  }

  getUserData(start_date: any, end_date: any, associate_id: any) {
    return this.http.post(this.url+'Dashboard/', { start_date, end_date, associate_id }, { headers: this.headers });
  }

  getUsersList() {
    return this.http.get(this.url+'users/', { headers: this.headers });
    // return of({
    //     "Success": true,
    //     "data": [
    //         {
    //             "user_id": "AL06692",
    //             "username": "Ganguly, Rit",
    //             "mail": "Rit.Ganguly@elevancehealth.com",
    //             "role": "ADMIN"
    //         },
    //         {
    //             "user_id": "AL06693",
    //             "username": "Sadhankar, Gopal",
    //             "mail": "Gopal.Sadhankar@elevancehealth.com",
    //             "role": "ASSOCIATE"
    //         },
    //         {
    //             "user_id": "AH24071",
    //             "username": "Kumudh, Chitthathur",
    //             "mail": "chitthathur.kumudh@elevancehealth.com",
    //             "role": "SUPERVISOR"
    //         },
    //         {
    //             "user_id": "AL17586",
    //             "username": "P, Sujata",
    //             "mail": "Sujata.P@elevancehealth.com",
    //             "role": "SUPERVISOR"
    //         },
    //         {
    //             "user_id": "AL19771",
    //             "username": "Bhutani, Preshika",
    //             "mail": "Preshika.Bhutani@elevancehealth.com",
    //             "role": "SUPERVISOR"
    //         },
    //         {
    //             "user_id": "AL06654",
    //             "username": "Kumar, Samir",
    //             "mail": "Samir.Kumar2@elevancehealth.com",
    //             "role": "ADMIN"
    //         }
    //     ]
    // })
  }

  // getData() {
  //   // let params = new HttpParams();

  //   // params = params.append('ag_id', this.agid);
  //   // return this.http.get(this.url+'?ag_id=' +this.agid);

  //   return of({
  //     "Success": true,
  //     "role": "ADMIN",
  //     "ag_id": "AL06625",
  //     "user_name": "Prudvi, Arimilli",
  //     "total_stat": {
  //       "total_claims": 898820,
  //       "total_success": 874895,
  //       "total_failure": 23425
  //     },
  //     "weekly_stat": {
  //       "label": [
  //         "2023-01-07",
  //         "2023-01-08",
  //         "2023-01-09",
  //         "2023-01-10",
  //         "2023-01-11",
  //         "2023-01-12",
  //         "2023-01-13",
  //         "2023-01-13",
  //         "2023-01-13"
  //       ],
  //       "success": [
  //         235,
  //         27853,
  //         24334,
  //         16843,
  //         23445,
  //         20934,
  //         25332,
  //         13442,
  //         12323
  //       ],
  //       "fail": [
  //         1002,
  //         3437,
  //         4599,
  //         3774,
  //         3645,
  //         4538,
  //         4534,
  //         3432,
  //         5637
  //       ]
  //     },
  //     "apps": [
  //       [
  //         {
  //           "data": [
  //             23453,
  //             5299
  //           ],
  //           "percentage": 74,
  //           "borderColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "backgroundColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "hoverBackgroundColor": [
  //             "#30bdc7",
  //             "#152f70"
  //           ],
  //           "hoverBorderColor": [
  //             "#fff",
  //             "#fff"
  //           ],
  //           "app": "WGS-MMCP"
  //         }
  //       ],
  //       [
  //         {
  //           "data": [
  //             56293,
  //             23034
  //           ],
  //           "percentage": 52,
  //           "borderColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "backgroundColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "hoverBackgroundColor": [
  //             "#30bdc7",
  //             "#152f70"
  //           ],
  //           "hoverBorderColor": [
  //             "#fff",
  //             "#fff"
  //           ],
  //           "app": "UAT AUTOMATION"
  //         }
  //       ],
  //       [
  //         {
  //           "data": [
  //             56293,
  //             23034
  //           ],
  //           "percentage": 52,
  //           "borderColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "backgroundColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "hoverBackgroundColor": [
  //             "#30bdc7",
  //             "#152f70"
  //           ],
  //           "hoverBorderColor": [
  //             "#fff",
  //             "#fff"
  //           ],
  //           "app": "UAT AUTOMATION"
  //         }
  //       ],
  //       [
  //         {
  //           "data": [
  //             536293,
  //             233034
  //           ],
  //           "percentage": 52,
  //           "borderColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "backgroundColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "hoverBackgroundColor": [
  //             "#30bdc7",
  //             "#152f70"
  //           ],
  //           "hoverBorderColor": [
  //             "#fff",
  //             "#fff"
  //           ],
  //           "app": "UAT AUTOMATION"
  //         }
  //       ],
  //       [
  //         {
  //           "data": [
  //             32893,
  //             2334
  //           ],
  //           "percentage": 52,
  //           "borderColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "backgroundColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "hoverBackgroundColor": [
  //             "#30bdc7",
  //             "#152f70"
  //           ],
  //           "hoverBorderColor": [
  //             "#fff",
  //             "#fff"
  //           ],
  //           "app": "UAT AUTOMATION"
  //         }
  //       ],
  //       [
  //         {
  //           "data": [
  //             32293,
  //             23034
  //           ],
  //           "percentage": 52,
  //           "borderColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "backgroundColor": [
  //             "#46c2cb",
  //             "#20376F"
  //           ],
  //           "hoverBackgroundColor": [
  //             "#30bdc7",
  //             "#152f70"
  //           ],
  //           "hoverBorderColor": [
  //             "#fff",
  //             "#fff"
  //           ],
  //           "app": "UAT AUTOMATION"
  //         }
  //       ]
  //     ]
  //   });

  //   //   return of({
  //   //     "Success": true,
  //   //     "total_stat": {
  //   //         "total_claims": 898820,
  //   //         "total_success": 874895,
  //   //         "total_failure": 23425
  //   //     },
  //   //     "weekly_stat": {
  //   //         "label": [
  //   //             "2023-01-07",
  //   //             "2023-01-08",
  //   //             "2023-01-09",
  //   //             "2023-01-10",
  //   //             "2023-01-11",
  //   //             "2023-01-12",
  //   //             "2023-01-13"
  //   //         ],
  //   //         "success": [
  //   //             18970,
  //   //             27853,
  //   //             24334,
  //   //             16843,
  //   //             23445,
  //   //             20934,
  //   //             25332
  //   //         ],
  //   //         "fail": [
  //   //             4129,
  //   //             3437,
  //   //             4599,
  //   //             3774,
  //   //             3645,
  //   //             4538,
  //   //             4534
  //   //         ]
  //   //     },
  //   //     "apps": [[
  //   //         {
  //   //           "data": [
  //   //               67365,
  //   //               37472
  //   //           ],
  //   //           "percentage": 64,
  //   //           "app": "MMCP"
  //   //         }],
  //   //         [{
  //   //           "data": [
  //   //               378437,
  //   //               65423
  //   //           ],
  //   //           "percentage": 36,
  //   //           "app": "OCA"
  //   //         }],
  //   //         [{
  //   //           "data": [
  //   //               442345,
  //   //               62433
  //   //           ],
  //   //           "percentage": 57,
  //   //           "app": "ASH"
  //   //         }],
  //   //         [{
  //   //           "data": [
  //   //               84327,
  //   //               22434
  //   //           ],
  //   //           "percentage": 76,
  //   //           "app": "JCode"
  //   //         }]
  //   //     ]
  //   // });

  //   // return of({
  //   //   "Success": true,
  //   //   "username":'samir',
  //   //   "data": [
  //   //     {
  //   //       "botname": "JCode",
  //   //       "state": "running",
  //   //       "total": 100,
  //   //       "processed": 90,
  //   //       "exceptions": 10
  //   //     },
  //   //     {
  //   //       "botname": "WGS LTSS",
  //   //       "state": "not running",
  //   //       "total": 50,
  //   //       "processed": 40,
  //   //       "exceptions": 10
  //   //     },
  //   //     {
  //   //       "botname": "UAT Automation",
  //   //       "state": "not running",
  //   //       "total": 30,
  //   //       "processed": 15,
  //   //       "exceptions": 15
  //   //     },
  //   //     {
  //   //       "botname": "Itemizes Billing",
  //   //       "state": "running",
  //   //       "total": 60,
  //   //       "processed": 55,
  //   //       "exceptions": 5
  //   //     },
  //   //     {
  //   //       "botname": "MMCP",
  //   //       "state": "not running",
  //   //       "total": 70,
  //   //       "processed": 40,
  //   //       "exceptions": 30
  //   //     },
  //   //     {
  //   //       "botname": "One Click Automation",
  //   //       "state": "running",
  //   //       "total": 50,
  //   //       "processed": 40,
  //   //       "exceptions": 10
  //   //     },
  //   //     {
  //   //       "botname": "ASH Claims",
  //   //       "state": "not running",
  //   //       "total": 50,
  //   //       "processed": 40,
  //   //       "exceptions": 10
  //   //     }
  //   //   ]
  //   // })

  // }

  // getAdminData(start_date: any, end_date: any, associate_id: any) {

  //   return this.http.post(this.url, { start_date, end_date, associate_id }, { headers: this.headers });

  //   // return this.http.get(this.adminurl+'?ag_id=' +this.agid);

  //   // return of({
  //   //   "Success": true,
  //   //   "username":"Admin",
  //   //   "data": [
  //   //     {
  //   //       "username": "admin",
  //   //       "appmetrics": [
  //   //         { "botname": "JCode", "state": "running", "total": 100, "processed": 90, "exceptions": 10 },
  //   //         { "botname": "WGS LTSS", "state": "not running", "total": 50, "processed": 40, "exceptions": 10 },
  //   //         { "botname": "Itemized Billing", "state": "running", "total": 70, "processed": 60, "exceptions": 10 },
  //   //         { "botname": "UAT Automation", "state": "not running", "total": 50, "processed": 30, "exceptions": 20 },
  //   //         { "botname": "One Click Automation", "state": "not running", "total": 60, "processed": 35, "exceptions": 25 }
  //   //       ]
  //   //     },
  //   //     {
  //   //       "username": "Sonu",
  //   //       "appmetrics": [
  //   //         { "botname": "JCode", "state": "running", "total": 60, "processed": 40, "exceptions": 20 },
  //   //         { "botname": "UAT Automation", "state": "not running", "total": 30, "processed": 20, "exceptions": 10 },
  //   //       ]
  //   //     },
  //   //     {
  //   //       "username": "Prudvi",
  //   //       "appmetrics": [
  //   //         { "botname": "Itemized Billing", "state": "running", "total": 70, "processed": 60, "exceptions": 10 },
  //   //         { "botname": "WGS LTSS", "state": " not running", "total": 50, "processed": 40, "exceptions": 10 },
  //   //         { "botname": "UAT Automation", "state": "not running", "total": 20, "processed": 15, "exceptions": 5 }
  //   //       ]
  //   //     }]
  //   // })
  // }
}
