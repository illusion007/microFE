import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { dashboardApiService } from './dashboard-api.service';

describe('dashboardApiService', () => {
  let service: dashboardApiService;
  let httpMock:HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(dashboardApiService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('#getUserData should call POST and get response if data is AVAILABLE.', () => {
    const mock = {
      "Success": true,
      "role": "ADMIN",
      "ag_id": "AL06653",
      "user_name": "Varshney, Aman",
      "total_stat": {
        "total_claims": 118,
        "total_success": 3,
        "total_failure": 115
      },
      "weekly_stat": {
        "label": [
            "2023-01-07",
            "2023-01-08",
            "2023-01-09",
            "2023-01-10"
        ],
        "success": [
            0,
            0,
            3,
            0
        ],
        "fail": [
            0,
            0,
            115,
            0
        ]
      },
      "apps": [
        [
            {
                "pieChartData": [
                    3,
                    99
                ],
                "percentage": 2.941176470588235,
                "borderColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "backgroundColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "hoverBackgroundColor": [
                    "#30bdc7",
                    "#152f70"
                ],
                "hoverBorderColor": [
                    "#fff",
                    "#fff"
                ],
                "app": "WGS-MMCP"
            }
        ],
        [
            {
                "pieChartData": [
                    0,
                    16
                ],
                "percentage": 0.0,
                "borderColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "backgroundColor": [
                    "#46c2cb",
                    "#20376F"
                ],
                "hoverBackgroundColor": [
                    "#30bdc7",
                    "#152f70"
                ],
                "hoverBorderColor": [
                    "#fff",
                    "#fff"
                ],
                "app": "UAT AUTOMATION"
            }
        ]
      ]
    }
    service.getUserData("startDate", "endDate", "").subscribe((res:any) => {
      expect(res.Success).toBeTruthy();
      expect(res.ag_id).toEqual("AL06653");
      expect(res.total_stat).toBeDefined();
      expect(res.Message).toBeUndefined();
    });
    const req = httpMock.expectOne((req) => req.method=='POST' && req.url==service.url);
    expect(req.request.method).toEqual('POST');
    req.flush(mock);
  });

  it('#getUserData should call POST and get response if data is NOT AVAILABLE.', () => {
    const mock = {
      "Success": true,
      "role": "ADMIN",
      "ag_id": "AL06653",
      "user_name": "Varshney, Aman",
      "Message": "No Records Found"
    }
    service.getUserData("startDate", "endDate", "").subscribe((res:any) => {
      expect(res.Success).toBeTruthy();
      expect(res.ag_id).toEqual("AL06653");
      expect(res.total_stat).toBeUndefined();
      expect(res.Message).toBeDefined();
    });
    const req = httpMock.expectOne((req) => req.method=='POST' && req.url==service.url);
    expect(req.request.method).toEqual('POST');
    req.flush(mock);
  });
});
