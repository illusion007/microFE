import { TestBed } from '@angular/core/testing';

import { DashboardSharedService } from './dashboard-shared.service';

describe('DashboardSharedService', () => {
  let service: DashboardSharedService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DashboardSharedService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should change value of loading.', () => {
    service.setLoading(true);
    service.getLoading().subscribe((loading: boolean) => {
      expect(loading).toBeTrue();
    })
  })

  it('should set response value.', () => {
    const mockResponse = {
      "Success": true,
      "role": "ADMIN",
      "ag_id": "AL06653",
      "user_name": "Varshney, Aman",
      "Message": "No Records Found"
    };
    service.setResponse(mockResponse);
    service.getResponse().subscribe((response: any) => {
      expect(response).toEqual(mockResponse);
    })
  });

  it('should set no data message correctly.', () => {
    const mockMessage = "No Records Found";
    service.setNoDataMessage(mockMessage);
    service.getNoDataMessage().subscribe((message: string) => {
      expect(message).toEqual("No Records Found");
    })
  });

  it('should set data available value correctly.', () => {
    service.setDataAvailable(false);
    service.getDataAvailable().subscribe((dataAvailable: boolean) => {
      expect(dataAvailable).toBeFalse();
    })
  })
});
