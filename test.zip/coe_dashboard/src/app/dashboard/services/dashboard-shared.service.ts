import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DashboardSharedService {

  private responseSubject: BehaviorSubject<any>;
  private loadingSubject: BehaviorSubject<boolean>;
  private dataSubject: BehaviorSubject<boolean>;
  private noDataMessage: BehaviorSubject<string>;

  constructor() {
    this.responseSubject = new BehaviorSubject<any>([]);
    this.loadingSubject = new BehaviorSubject<boolean>(false);
    this.dataSubject = new BehaviorSubject<boolean>(true);
    this.noDataMessage = new BehaviorSubject<string>("");
  }

  public setNoDataMessage(msg: string) {
    this.noDataMessage.next(msg);
  }

  public getNoDataMessage() {
    return this.noDataMessage.asObservable();
  }

  public setDataAvailable(val: boolean) {
    this.dataSubject.next(val);
  }

  public getDataAvailable() {
    return this.dataSubject.asObservable();
  }

  public setResponse(val: any) {
    this.responseSubject.next(val);
  }

  public getResponse() {
    return this.responseSubject.asObservable();
  }

  public setLoading(val: boolean) {
    this.loadingSubject.next(val);
  }

  public getLoading() {
    return this.loadingSubject.asObservable();
  }

}
