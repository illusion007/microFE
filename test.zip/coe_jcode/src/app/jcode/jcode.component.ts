import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { JcodeSharedService } from './services/jcode-shared.service';

@Component({
  selector: 'app-jcode',
  templateUrl: './jcode.component.html',
  styleUrls: ['./jcode.component.css']
})
export class JCodeComponent implements OnInit {
  loading: boolean = false;

  constructor(private jcodeSharedService: JcodeSharedService, private location: Location) {
    this.jcodeSharedService.loading.subscribe((x) => (this.loading = x));
  }

  hadData: boolean = false;
  claims = [];
  app = {
    appname: 'JCode',
    app_description:
      'To provide picing as per guideleines to ensure accurate and  timely processing of claims submited with NOC timely processing of claims submited with NOC ',
    app_health: true,
    accuracy: '92.33%',
    downtime: '30 sec.',
    runs_in_progress: 2
  };

  ngOnInit() {}

  receiveData($event: any) {
    this.claims = $event;
    this.hadData = true;
  }

  navigateToMyApps() {
    this.location.back();
  }

  runAppAgain() {
    this.hadData = false;
  }
}
