import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HttpClientModule } from '@angular/common/http';
import { TableModule } from 'primeng/table';
import { ProgressBarModule } from 'primeng/progressbar';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

import { JCodeComponent } from './jcode.component';
import { JCodeRoutingModule } from './jcode.routing.module';
import { ReportsComponent } from './components/reports/reports.component';
import { UploadComponent } from './components/upload/upload.component';
import { JCodeApiService } from './services/jcode-api.service';
import { FormsModule } from '@angular/forms';
import { DndDirective } from './components/upload/dnd.directive';
import { JcodeSharedService } from './services/jcode-shared.service';

@NgModule({
  declarations: [JCodeComponent, ReportsComponent,DndDirective, UploadComponent],
  imports: [
    CommonModule,
    FormsModule,
    JCodeRoutingModule,
    TableModule,
    ProgressSpinnerModule,
    ToastModule,
    ProgressBarModule,
    HttpClientModule
  ],
  providers: [JCodeApiService,JcodeSharedService,MessageService]
})
export class JCodeModule {}
