import { ComponentFixture, TestBed} from '@angular/core/testing';
import { of } from 'rxjs';

import { JCodeComponent } from './jcode.component';
import { JCodeApiService } from './services/jcode-api.service';

describe('JCodeComponent', () => {
  let component: JCodeComponent;
  let fixture: ComponentFixture<JCodeComponent>;
  let jcodeApiServiceSpy: any;
  let apiResponseData = 
  {
    "data": [
        {
          "claim_number": 2345678,
          "line_status": "Deny with Y87"
        },
        {
          "claim_number": 12345678,
          "line_status": "Processed"
        },
        {
          "claim_number": 12345678,
          "line_status": "Processed"
        }
    ],
    "total_count": 3, 
    "filename": "test_file_1",
    "Success": true,
    "Message": "no_error"
}


  beforeEach(async () => {
    jcodeApiServiceSpy = jasmine.createSpyObj('jcode-api',['runApp']);
    jcodeApiServiceSpy.runApp.and.returnValue(of(apiResponseData));
    await TestBed.configureTestingModule({
      declarations: [ JCodeComponent ],
      providers:[JCodeApiService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to all apps', () => {
    spyOn(component, 'navigateToMyApps').and.callThrough();
    let button = fixture.debugElement.nativeElement.querySelector('.back');
    button.click();
    expect(component.navigateToMyApps).toHaveBeenCalledTimes(1);
  });

  it('should run app again', () => {
    component.hadData = true;
    fixture.detectChanges();
    spyOn(component, 'runAppAgain').and.callThrough();
    let button = fixture.debugElement.nativeElement.querySelector('.run-app-again');
    button.click();
    expect(component.runAppAgain).toHaveBeenCalledTimes(1);
  })

});
