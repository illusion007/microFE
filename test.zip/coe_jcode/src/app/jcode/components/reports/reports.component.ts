import { Component, Input, OnInit } from '@angular/core';
import { JcodeSharedService } from '../../services/jcode-shared.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css'],
})
export class ReportsComponent implements OnInit {
  @Input() claims: any;
  processed_count=0;
  exception_count=0;
  filtered_claims:any;
  selected_claimStatus='all';
  constructor(private jcodeSharedService:JcodeSharedService) {}

  ngOnInit(): void {
    this.filtered_claims=this.claims.data;
    this.processed_count=this.claims.data.filter((x:any)=>{
      if(x.line_status=='Processed')
      return x;
    }).length;
    this.exception_count=this.claims.total_count-this.processed_count;
  }

  changeInClaimStatus(){
    if(this.selected_claimStatus=='all')
    {
      this.filtered_claims=this.claims.data;
    }
    else if(this.selected_claimStatus=='processed')
    {
      this.filtered_claims=this.claims.data.filter((x:any)=>{
        if(x.line_status=='Processed')
        return x;
      })
    }
    else{
      this.filtered_claims=this.claims.data.filter((x:any)=>{
        if(x.line_status!='Processed')
        return x;
      })
    }
  }

  exportExcel() {
    import('xlsx').then((xlsx) => {
      const worksheet = xlsx.utils.json_to_sheet(this.claims.data);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, {
        bookType: 'xlsx',
        type: 'array',
      });
      this.jcodeSharedService.saveAsExcelFile(excelBuffer, 'Jcode_file_export_' + new Date().getTime());
    });
  }

}
