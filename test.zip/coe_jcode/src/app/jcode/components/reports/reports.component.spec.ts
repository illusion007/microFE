import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { JCodeComponent } from '../../jcode.component';
import { ReportsComponent } from './reports.component';
import { By } from '@angular/platform-browser';

describe('ReportsComponent', () => {
  let component: ReportsComponent;
  let fixture: ComponentFixture<ReportsComponent>;

  let jcodeComponent: JCodeComponent;
  let jcodeFixture: ComponentFixture<JCodeComponent>;

  let response = 
    {
      "data": [
          {
              "claim_number": 2345678,
              "line_status": "Deny with Y87",
          },
          {
              "claim_number": 12345678,
              "line_status": "Processed",
          },
          {
              "claim_number": 12345678,
              "line_status": "Processed",
          }
      ],
      "total_count": 3, 
      "filename": "test_file_1",
      "Success": true,
      "Message": "no_error"
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportsComponent ]
    })
    .compileComponents();

    jcodeFixture = TestBed.createComponent(JCodeComponent);
    jcodeComponent = jcodeFixture.componentInstance;
    jcodeComponent.hadData = true;

    fixture = TestBed.createComponent(ReportsComponent);
    component = fixture.componentInstance;

    component.claims = response;

    fixture.detectChanges();

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should evaluate the number of processed claims count correctly', () => {
    expect(component.processed_count).toEqual(2);
  })

  it('should evaluate the number of exception count correctly', () => {
    expect(component.exception_count).toEqual(1);
  })

  it('should export the processed excel file and get ready for download', () => {
    spyOn(component, 'exportExcel').and.callThrough();
    let button = fixture.debugElement.nativeElement.querySelector('.download');
    button.click();
    expect(component.exportExcel).toHaveBeenCalledTimes(1);
  })

  it('should show `all` as option value and filter', fakeAsync(() => {
    fixture.whenStable().then(() => {
      spyOn(component, 'changeInClaimStatus').and.callThrough();
      const select = fixture.debugElement.query(By.css('select')).nativeElement;
      select.value = select.options[0].value;
      component.selected_claimStatus = select.value;
      select.dispatchEvent(new Event('change'));
      fixture.detectChanges();
      expect(component.changeInClaimStatus).toHaveBeenCalled();
      expect(component.claims.total_count).toEqual(3);
      expect(component.filtered_claims.length).toEqual(3);
    });
  }));

  it('should show `Processed` as option value and filter', fakeAsync(() => {
    fixture.whenStable().then(() => {
      spyOn(component, 'changeInClaimStatus').and.callThrough();
      const select = fixture.debugElement.query(By.css('select')).nativeElement;
      select.value = select.options[1].value;
      component.selected_claimStatus = select.value;
      select.dispatchEvent(new Event('change'));
      fixture.detectChanges();
      expect(component.changeInClaimStatus).toHaveBeenCalled();
      expect(component.processed_count).toEqual(2);
      expect(component.filtered_claims.length).toEqual(2);
    });
  }));

  it('should show `Exception` as option value and filter', fakeAsync(() => {
    fixture.whenStable().then(() => {
      spyOn(component, 'changeInClaimStatus').and.callThrough();
      const select = fixture.debugElement.query(By.css('select')).nativeElement;
      select.value = select.options[2].value;
      component.selected_claimStatus = select.value;
      select.dispatchEvent(new Event('change'));
      fixture.detectChanges();
      expect(component.changeInClaimStatus).toHaveBeenCalled();
      expect(component.exception_count).toEqual(1);
      expect(component.filtered_claims.length).toEqual(1);
    });
  }));

});
