import { HttpClientModule, HttpErrorResponse } from '@angular/common/http';
import { ElementRef } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { MessageService } from 'primeng/api';
import { of, throwError } from 'rxjs';
import { JCodeApiService } from '../../services/jcode-api.service';
import { UploadComponent } from './upload.component';

describe('UploadComponent', () => {
  let component: UploadComponent;
  let fixture: ComponentFixture<UploadComponent>;

  let jcodeApiServiceSpy!:any;

  let jcodeSharedServiceSpy !: any;
  
  let apiSpy;
  let res = {
      "Success" : false,
      "Message" : 'error'
    }
  let response = 
    {
      "data": [
          {
              "claim_number": 2345678,
              "line_status": "Deny with Y87",
          },
          {
              "claim_number": 12345678,
              "line_status": "Processed",
          },
          {
              "claim_number": 12345678,
              "line_status": "Processed",
          }
      ],
      "total_count": 3, 
      "filename": "test_file_1",
      "Success": true,
      "Message": "no_error"
  };

  beforeEach(async () => {

    jcodeApiServiceSpy = jasmine.createSpyObj('JCodeApiService',['runApp']);
    jcodeApiServiceSpy.runApp.and.returnValue(of(response));

    jcodeSharedServiceSpy = jasmine.createSpyObj('JCodeSharedService', ['saveAsExcelFile']);

    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ UploadComponent ],
      providers: [MessageService, {provide:JCodeApiService,useValue:jcodeApiServiceSpy}]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should download the sample file', () => {
    spyOn(component, 'downloadSampleFile').and.callThrough();
    let button = fixture.debugElement.nativeElement.querySelector('.sample-file');
    button.click();
    expect(component.downloadSampleFile).toHaveBeenCalledTimes(1);
  });


  it('should detect file input change and set upload file status', () => {
    const dataTransfer = new DataTransfer()
    dataTransfer.items.add(new File([''], 'test-file.xls'));
    const inputDebugEl  = fixture.debugElement.query(By.css('input[type=file]'));
    inputDebugEl.nativeElement.files = dataTransfer.files;
    inputDebugEl.nativeElement.dispatchEvent(new InputEvent('change'));
    fixture.detectChanges();
    expect(component.showUploadStatus).toBeTruthy();
    expect(component.filename).toBe('test-file.xls');
  });


  it('file change event should arrive in handler', () => {
    spyOn(component, 'fileBrowseHandler');
    const input = fixture.debugElement.nativeElement.querySelector('#fileDropRef');
    input.dispatchEvent(new Event('change'));
    fixture.detectChanges();
    expect(component.fileBrowseHandler).toHaveBeenCalledTimes(1);
  });

  it('should delete the uploaded file on clicking delete button', fakeAsync(() => {
    spyOn(component, 'deleteFile').and.callThrough();
    const dataTransfer = new DataTransfer()
    dataTransfer.items.add(new File([''], 'test-file.xls'));
    const inputDebugEl  = fixture.debugElement.query(By.css('input[type=file]'));
    inputDebugEl.nativeElement.files = dataTransfer.files;
    inputDebugEl.nativeElement.dispatchEvent(new InputEvent('change'));
    fixture.detectChanges();
    let button = fixture.debugElement.nativeElement.querySelector(".file-details>span");
    button.click();
    expect(component.deleteFile).toHaveBeenCalledTimes(1);
    expect(component.files.length).toEqual(0);
    expect(component.filename).toEqual('');
    expect(component.showUploadStatus).toBeFalsy();
  }));
  

  it('should display the uploaded filename correctly', () => {
    const dataTransfer = new DataTransfer()
    dataTransfer.items.add(new File([''], 'test-file.xls'));
    const inputDebugEl  = fixture.debugElement.query(By.css('input[type=file]'));
    inputDebugEl.nativeElement.files = dataTransfer.files;
    inputDebugEl.nativeElement.dispatchEvent(new InputEvent('change'));
    fixture.detectChanges();
    let elem = fixture.debugElement.query(By.css('.file-card p')).nativeElement;
    expect(component.filename).toEqual(elem.textContent);
  })


  it('should run the app after uploading the file', () => {
    spyOn(component, 'runApp').and.callThrough();
    const dataTransfer = new DataTransfer()
    dataTransfer.items.add(new File([''], 'test-file.xls'));
    const inputDebugEl  = fixture.debugElement.query(By.css('input[type=file]'));
    inputDebugEl.nativeElement.files = dataTransfer.files;
    inputDebugEl.nativeElement.dispatchEvent(new InputEvent('change'));
    fixture.detectChanges();
    let button = fixture.debugElement.nativeElement.querySelector('.run-app');
    button.click();
    expect(component.runApp).toHaveBeenCalledTimes(1);
    expect(jcodeSharedServiceSpy.setLoading).toBeFalsy();
    expect(component.claims).toEqual(response);
  });

  it('should run the app after uploading the file, and receive success false message with error', () => {
    const err=new HttpErrorResponse({
      error:{code:400,message:"error",status:400},
      statusText:'Bad Request'
    })
    jcodeApiServiceSpy.runApp.and.returnValue(throwError(err))
    const dataTransfer = new DataTransfer()
    dataTransfer.items.add(new File([''], 'test-file.xls'));
    const inputDebugEl  = fixture.debugElement.query(By.css('input[type=file]'));
    inputDebugEl.nativeElement.files = dataTransfer.files;
    inputDebugEl.nativeElement.dispatchEvent(new InputEvent('change'));
    fixture.detectChanges();
    let button = fixture.debugElement.nativeElement.querySelector('.run-app');
    button.click();
    expect(component.claims.length).toEqual(0);
  })

});
