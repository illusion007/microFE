import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MessageService } from 'primeng/api';
import { JCodeApiService } from '../../services/jcode-api.service';
import { JcodeSharedService } from '../../services/jcode-shared.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
  files: any[] = [];
  showUploadStatus: boolean = false;
  uploaded: boolean = false;
  filename = '';
  claims: any = [];

  @Output() sendData = new EventEmitter<any>();
  eta: any = 0;
  pid: any;
  seconds: number = 0;
  displaySec: any;
  displayminutes: any = '';
  dialog: boolean = false;
  message: any = '';
  interval: any = 0;
  constructor(
    private apiService: JCodeApiService,
    private jcodeSharedService: JcodeSharedService,
    private messageService: MessageService
  ) {}

  ngOnInit(): void {}

  /**
   * on file drop handler
   */
  onFileDropped($event: any) {
    this.prepareFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler($event: any) {
    this.prepareFilesList($event.target.files);
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      item.progress = 0;
      this.files.push(item);
    }
    this.filename = this.files[0].name;
    this.showUploadStatus = true;
  }

  deleteFile() {
    this.files = [];
    this.filename = '';
    this.showUploadStatus = false;
  }

  startTimer() {
    let val = 0;
    this.seconds = this.eta;
    this.displayminutes = Math.floor(this.eta / 60)
      .toString()
      .padStart(2, '0');
    this.displaySec = (this.eta % 60).toString().padStart(2, '0');
    this.interval = setInterval(() => {
      if (this.seconds > 1) {
        this.seconds--;
        this.displayminutes = Math.floor(this.seconds / 60)
          .toString()
          .padStart(2, '0');
        this.displaySec = (this.seconds % 60).toString().padStart(2, '0');
      } else {
        this.seconds = 0;
        clearInterval(this.interval);
        this.messageService.clear();
      }
    }, 1000);
  }

  close() {
    this.dialog = false;
    this.message = '';
    clearInterval(this.interval);
  }

  confirmdialog() {
    this.dialog = true;
    this.startTimer();
  }

  fetchData() {
    // clearInterval(this.interval);
    this.message = '';
    this.messageService.clear();
    this.getData();
  }

  getData() {
    this.apiService.getRunApp(this.pid).subscribe({
      next: (res: any) => {
        if (res.Success) {
          if (res.data && res.data.length >= 0) {
            this.dialog = false;
            this.claims = res;
            this.claims.filename = this.filename;
            this.sendData.emit(this.claims);
          } else if (res.eta && res.eta >= 0) {
            this.eta = res.eta;
            this.pid = res.pid;
            this.message = res.Message;
            this.confirmdialog();
          }
        } else {
          this.messageService.add({ sticky: true, severity: 'error', summary: res.Message });
        }
      },
      error: (err: any) => {
        
        this.messageService.add({ sticky: true, severity: 'error', summary: 'something went wrong' });
      }
    });
  }

  runApp() {
    this.jcodeSharedService.setLoading(true);
    let formdata = new FormData();
    formdata.append('claim_file', this.files[0]);
    this.apiService.runApp(formdata).subscribe({
      next: (res: any) => {
        this.jcodeSharedService.setLoading(false);
        
        if (res.Success) {
          if (res.data && res.data.length >= 0) {
            this.claims = res;
            this.claims.filename = this.filename;
            this.sendData.emit(this.claims);
          } else if (res.eta && res.eta >= 0) {
            this.eta = res.eta;
            this.pid = res.pid;
            this.confirmdialog();
          }
        } else {
          this.messageService.add({ sticky: true, severity: 'error', summary: res.Message });
        }
      },
      error: (err: any) => {
        
        this.jcodeSharedService.setLoading(false);
        this.messageService.add({ sticky: true, severity: 'error', summary: 'something went wrong' });
      }
    });
  }

  downloadSampleFile() {
    import('xlsx').then((xlsx) => {
      const worksheet = xlsx.utils.json_to_sheet([
        {
          'Claim Number': '',
          'Line Number': '',
          'Service Date': '',
          'Proc code': '',
          'Bill Amount': '',
          Units: '',
          'NDC CODE': ''
        }
      ]);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, {
        bookType: 'xlsx',
        type: 'array'
      });
      this.jcodeSharedService.saveAsExcelFile(excelBuffer, 'Jcode_Samplefile');
    });
  }
}
