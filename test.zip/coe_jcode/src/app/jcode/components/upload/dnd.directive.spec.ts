import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ElementRef } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MessageService } from 'primeng/api';
import { TableModule } from 'primeng/table';
import { ToastModule } from 'primeng/toast';
import { DndDirective } from './dnd.directive';
import { UploadComponent } from './upload.component';

describe('DndDirective', () => {
  let directive: DndDirective
  let component: UploadComponent
  let fixture: ComponentFixture<UploadComponent>;
    beforeEach(async () => {
        await TestBed.configureTestingModule({
          declarations: [ UploadComponent, DndDirective ],
          imports: [ HttpClientTestingModule,TableModule,ToastModule ],
          providers: [ MessageService ]
        })
        .compileComponents();
     });
   beforeEach(() => {
      fixture = TestBed.createComponent(UploadComponent);
      component = fixture.componentInstance
      fixture.detectChanges();
  })

  it('should create an instance', () => {
    const directive = new DndDirective();
    expect(directive).toBeTruthy();
  });

  it('should verify the directive recognises a drop event', () => {  
    spyOn(component, 'onFileDropped')
    const el: ElementRef = fixture.debugElement
    const fileDropArea: HTMLDivElement =el.nativeElement.querySelector('.drag-wrapper')
    const file = new File([''], 'dummy.xls')
    const dataTransfer = new DataTransfer()
    dataTransfer.items.add(file)
    const event = new DragEvent("drop", { dataTransfer })
    fileDropArea.dispatchEvent(event)
    fixture.detectChanges()
    expect(component['onFileDropped']).toHaveBeenCalledWith(dataTransfer.files)
  });

  it('should verify the directive recognises a drag event', () => {
    spyOn(component, 'fileBrowseHandler')
    const el: ElementRef = fixture.debugElement
    const fileDropArea: HTMLDivElement =el.nativeElement.querySelector('.drag-wrapper')
    fixture.detectChanges();
    const event = new Event('dragover', { bubbles: true });
    spyOn(event, 'preventDefault');
    fileDropArea.dispatchEvent(event); 
    expect(event.preventDefault).toHaveBeenCalled();
  });

  it('should verify the directive recognises a dragleave event', () => {
    spyOn(component, 'fileBrowseHandler')
    const el: ElementRef = fixture.debugElement
    const fileDropArea: HTMLDivElement =el.nativeElement.querySelector('.drag-wrapper')
    fixture.detectChanges();
    const event = new Event('dragleave', { bubbles: true });
    spyOn(event, 'preventDefault');
    fileDropArea.dispatchEvent(event); 
    expect(event.preventDefault).toHaveBeenCalled();
  });
  
});
