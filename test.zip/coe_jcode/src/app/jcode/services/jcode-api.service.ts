import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { of } from 'rxjs';
import * as CryptoJS from 'crypto-js';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class JCodeApiService {
  url = environment.serverUrl + 'jcode_app/';
  // agid = localStorage.getItem('agid') || '';
  private key: string;
  private headers: HttpHeaders;

  constructor(private http: HttpClient) {
    this.key = '000102030405060708090a0b0c0d0e0f';
    const decrypted = CryptoJS.AES.decrypt(localStorage.getItem('token') || '', this.key).toString(CryptoJS.enc.Utf8);
    this.headers = new HttpHeaders().append('Authorization', JSON.parse(JSON.stringify(decrypted)));
  }

  runApp(data: any) {
    // let params = new HttpParams();
    // params = params.append('ag_id', this.agid);
    // return this.http.post(this.url, data, { params: params });
    return this.http.post(this.url, data, { headers: this.headers });

    //   return of({
    //     Success:true,
    //     "data": [
    //     {
    //         "claim_number": 2345678,
    //         "dt": "2022-07",
    //         "line_number": 5,
    //         "proc": "J8499",
    //         "ndc_code": "00004-0800-85",
    //         "units": 5,
    //         "billcharge": 1.256,
    //         "redbook_desc": "TAMIFLU",
    //         "line_status": "Deny with Y87",
    //         "calculated_price": 'NAN'
    //     },
    //     {
    //       "claim_number": 12345678,
    //       "dt": "2022-07",
    //       "line_number": 5,
    //       "proc": "J8499",
    //       "ndc_code": "00004-0800-85",
    //       "units": 5,
    //       "billcharge": 1.256,
    //       "redbook_desc": "TAMIFLU",
    //       "line_status": "Processed",
    //       "calculated_price": 'NAN'
    //   }
    // ],
    // 'total_count': 2})

    // return of({
    //   Success:false,
    //   Message:'error'

    // })
  }

  getRunApp(pid: any) {
    return this.http.get(`${this.url}?pid=${pid}`, { headers: this.headers });
  }
}
