import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { JCodeApiService } from './jcode-api.service';
import { environment } from 'src/environments/environment';

describe('JCodeApiService', () => {
  let service: JCodeApiService;
  let httpMock:HttpTestingController;
  let url = environment.serverUrl + 'jcode_app/';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [JCodeApiService]
    });
    service = TestBed.inject(JCodeApiService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();     
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('#runApp should call POST and get response', () => {
    const mock = {
      "data": [
          {
              "claim_number": 2345678,
              "line_status": "Deny with Y87",
          },
          {
              "claim_number": 12345678,
              "line_status": "Processed",
          },
          {
              "claim_number": 12345678,
              "line_status": "Processed",
          }
      ],
      "total_count": 3, 
      "filename": "test_file_1",
      "Success": true,
      "Message": "no_error"
    };

    let data!:FormData;
    service.runApp(data)
      .subscribe((Data:any) => {
        expect(Data["filename"]).toEqual("test_file_1");
      });
    let agid=localStorage.getItem('agid')||'';
    // const req = httpMock.expectOne(environment.serverUrl+'jcode_app/?ag_id='+agid);
    const req = httpMock.expectOne((req)=>req.method=='POST' && req.url==service.url);
    expect(req.request.method).toEqual('POST');
    req.flush(mock);
    
  });


  it('should call GET getRunApp and return expected data', (done) => {
    const expectedData:any=[];
    let data_agid!:FormData
    service.getRunApp(data_agid).subscribe(data => {
      expect(data).toEqual(expectedData);
      done();
    }); 
    const req = httpMock.expectOne(service.url+'?pid='+data_agid);
    req.flush(expectedData);
    expect(req.request.method).toEqual('GET');
  });

});

