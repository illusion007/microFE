import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { saveAs } from 'file-saver';

@Injectable({
  providedIn: 'root'
})
export class JcodeSharedService {

  private loadingSubject: BehaviorSubject<boolean>;
  public loading:Observable<boolean>;
  constructor() {
    this.loadingSubject = new BehaviorSubject<boolean>(false);
    this.loading= this.loadingSubject.asObservable();
   }

  public setLoading(val:boolean) {
    this.loadingSubject.next(val);
  
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE =
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE,
    });
    saveAs(
      data,
      fileName + EXCEL_EXTENSION
    );
  }
}
