import { TestBed } from '@angular/core/testing';

import { JcodeSharedService } from './jcode-shared.service';

describe('JcodeSharedService', () => {
  let service: JcodeSharedService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JcodeSharedService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should change value of loading to true if setLoading is called with true', () => {
    service.setLoading(true);
    service.loading.subscribe((x: boolean) => {
      expect(x).toBeTrue();
    })
  })

  it('should change value of loading to false if setLoading is called with false', () => {
    service.setLoading(false);
    service.loading.subscribe((x: boolean) => {
      expect(x).toBeFalse();
    })
  })
});
