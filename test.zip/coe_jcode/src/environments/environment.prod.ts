export const environment = {
  production: true,
  serverUrl: 'http://va33dlvjre309:8000/'
};
