import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-nav-sidebar',
  templateUrl: './nav-sidebar.component.html',
  styleUrls: ['./nav-sidebar.component.css']
})
export class NavSidebarComponent implements OnInit {
  isLoggedIn$!: Observable<boolean>;
  userRole: any
  constructor(private authService: AuthService) {}

  ngOnInit() {
    this.isLoggedIn$ = this.authService.isLoggedIn;
    this.authService.userRoleSubject.subscribe((res) => {
      this.userRole = res;
    });
  }

  logout() {
    localStorage.clear();
    this.authService.logout();
    window.location.href = '/login';
  }
}
