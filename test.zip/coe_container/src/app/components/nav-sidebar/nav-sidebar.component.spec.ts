import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { MessageService } from 'primeng/api';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import { NavSidebarComponent } from './nav-sidebar.component';

describe('NavSidebarComponent', () => {
  let component: NavSidebarComponent;
  let fixture: ComponentFixture<NavSidebarComponent>;

  let authServiceSpy: any;

  const val = new BehaviorSubject<boolean>(true);

  beforeEach(async () => {
    authServiceSpy = jasmine.createSpyObj('AuthService', ['logout'], {'isLoggedIn': val});
    authServiceSpy.loggedIn = val;

    await TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule, FormsModule, ReactiveFormsModule, RouterTestingModule ],
      declarations: [ NavSidebarComponent ],
      providers: [{provide: AuthService, useValue: authServiceSpy}, MessageService] 
    })
    .compileComponents();

    fixture = TestBed.createComponent(NavSidebarComponent);
    component = fixture.componentInstance;
    
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should login, set isLoggedIn observable to true and display dom', () => {
    let container = fixture.debugElement.nativeElement.querySelector('.container');
    expect(component.isLoggedIn$).toBeUndefined();
    expect(container).toBeNull();
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.isLoggedIn$).toBeDefined();
    expect(container).toBeDefined();
    component.isLoggedIn$.subscribe((res) => {
      expect(res).toBeTrue();
    })
  })

  it('should logout and navigate to login page', () => {
    spyOn(component, 'logout').and.callThrough();
    component.ngOnInit();
    fixture.detectChanges()
    let logoutButton = fixture.debugElement.nativeElement.querySelector('.user div:nth-child(3)');
    logoutButton.click();
    expect(component.logout).toHaveBeenCalled();
    expect(authServiceSpy.logout).toHaveBeenCalled();
  })

});