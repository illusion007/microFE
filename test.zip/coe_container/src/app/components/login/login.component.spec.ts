import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { LoginComponent } from './login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  let authServiceSpy: any;
  let routerSpy: any;
  let messageServiceSpy: any;

  let username: any;
  let password: any;

  // let mockUser = {token:'we345rjjfui',username:'user',mail:'user.mail.com',role:1,userid:'id'};
  
  authServiceSpy = jasmine.createSpyObj('AuthService', ['login']);
  routerSpy = jasmine.createSpyObj('Router',['navigate']);
  messageServiceSpy = jasmine.createSpyObj('MessageService', ['add']);

  beforeEach(async () => {
    authServiceSpy.login.and.returnValue(of({'token':'asdfrg',role:1}));
    await TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule, FormsModule, ReactiveFormsModule ],
      declarations: [ LoginComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      providers:[MessageService, {provide: AuthService,useValue:authServiceSpy}, {provide:Router,useValue:routerSpy}]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check validity of username', () => {
    username = component.form.controls['username'];
    expect(username.valid).toBeFalsy();
    expect(username.errors['required']).toBeTruthy();
    username.setValue('AH24071');
    expect(username.valid).toBeTruthy();
  });

  it('should check validity of Password', () => {
    password = component.form.controls['pwd'];
    expect(password.valid).toBeFalsy();
    expect(password.errors['required']).toBeTruthy();
    password.setValue('AH24071');
    expect(password.valid).toBeTruthy();
  });

  it('should check form validity', () => {
    expect(component.form.valid).toBeFalsy();
    component.form.controls['username'].setValue('AH24071');
    component.form.controls['pwd'].setValue('AH24071');
    expect(component.form.valid).toBeTruthy();
  });

  it('should check login button is enabled or not if values are entered and calls "login" method in service and navigated to dashboard page', () => {
    expect(component.form.valid).toBeFalsy();
    let btn = fixture.debugElement.nativeElement.querySelector('input[type=submit]');
    expect(btn.disabled).toBeTruthy();
    component.form.controls['username'].setValue('AH24071');
    component.form.controls['pwd'].setValue('AH24071');
    fixture.detectChanges();
    expect(btn.disabled).toBeFalsy();
    btn.click();
    expect(authServiceSpy.login).toHaveBeenCalled();
    expect(localStorage['agid']).toEqual('AH24071');
    expect(routerSpy.navigate).toHaveBeenCalledWith(['/dashboard']);
  })

  it('should add a toast message to message service if any error occurs in logging in', () => {
    component.form.controls['username'].setValue('AH24071');
    component.form.controls['pwd'].setValue('AH24071');
    fixture.detectChanges();
    const err=new HttpErrorResponse({
      error:{code:400,message:"Something went wrong",status:400},
      statusText:'Bad Request'
    })
    authServiceSpy.login.and.returnValue(throwError(err));
    let btn = fixture.debugElement.nativeElement.querySelector('input[type=submit]');
    btn.click();
    expect(authServiceSpy.login).toHaveBeenCalled();
  })

});
