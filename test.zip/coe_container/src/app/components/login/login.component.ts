import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import * as CryptoJS from 'crypto-js';

import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form!: FormGroup;
  userRole: any;
  constructor(
    private readonly fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private messageService: MessageService
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      username: ['', Validators.required],
      pwd: ['', Validators.required]
    });
  }

  submitForm() {
    if (!this.form.valid) {
      return;
    }
    const requestData = {
      user_id: this.form.value.username.toUpperCase(),
      password: this.form.value.pwd
    };
    this.authService.login(requestData).subscribe({
      next: (res: any) => {
        if (res) {
          localStorage.setItem('agid', this.form.controls['username'].value);
          // localStorage.setItem('username', res.access_token.username);
          // localStorage.setItem('role', JSON.stringify(res.access_token.role));
          const key = '000102030405060708090a0b0c0d0e0f';
          const encrypted = CryptoJS.AES.encrypt(res.access_token.token.toString(), key).toString();
          this.userRole = res.access_token.role;
          this.authService.setUserRole(this.userRole);
          localStorage.setItem('token', encrypted);
          // localStorage.setItem('role', JSON.stringify(res.access_token.role));
          this.router.navigate(['/dashboard']);
        }
      },
      error: (err: any) => {
        this.messageService.add({
          sticky: true,
          severity: 'error',
          summary: err?.error?.Message || err?.message || 'Something went wrong'
        });
      }
    });
  }
}
