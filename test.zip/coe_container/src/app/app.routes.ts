import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { loadRemoteModule } from '@angular-architects/module-federation';
import { AuthGuard } from './services/auth.guard';
import { environment } from './../environments/environment';

export const APP_ROUTES: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', title: 'Login', component: LoginComponent },
  {
    path: 'dashboard',
    title: 'Dashboard',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.dashboard,
        exposedModule: './Module'
      }).then((m) => m.DashboardModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'myApps',
    title: 'My Apps',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.myApps,
        exposedModule: './Module'
      }).then((m) => m.MyAppsModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'jcode',
    title: 'JCode',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.jcode,
        exposedModule: './Module'
      }).then((m) => m.JCodeModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'ltss',
    title: 'WGS - LTSS',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.ltss,
        exposedModule: './Module'
      }).then((m) => m.LtssModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'mmcp',
    title: 'WGS - MMCP',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.mmcp,
        exposedModule: './Module'
      }).then((m) => m.MmcpModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'oca',
    title: 'One Click Automation',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.oca,
        exposedModule: './Module'
      }).then((m) => m.OcaModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'ib',
    title: 'Itemized Billing',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.ib,
        exposedModule: './Module'
      }).then((m) => m.ItemizedBillingModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'ash',
    title: 'Ash',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.ash,
        exposedModule: './Module'
      }).then((m) => m.AshModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'uat_automation',
    title: 'Uat Automation',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.uatAutomation,
        exposedModule: './Module'
      }).then((m) => m.UatAutomationModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'myRuns',
    title: 'My Runs',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.myRuns,
        exposedModule: './Module'
      }).then((m) => m.MyRunsModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'botAssignment',
    title: 'Bot Assignment',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.botAssignment,
        exposedModule: './Module'
      }).then((m) => m.AssignbotModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'dce',
    title: 'DCE Audits Automation',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.dce,
        exposedModule: './Module'
      }).then((m) => m.DceModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'kcua',
    title: 'Keying Claims',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.kcua,
        exposedModule: './Module'
      }).then((m) => m.KcuaModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'cc',
    title: 'Claims Consolidation',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.cc,
        exposedModule: './Module'
      }).then((m) => m.ClaimsConsolidatedModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'repairManagement',
    title: 'Repair Management',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.repairManagement,
        exposedModule: './Module'
      }).then((m) => m.RmaModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'eca',
    title: 'Encounters Automation',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.eca,
        exposedModule: './Module'
      }).then((m) => m.EcaModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'Medsup',
    title: 'Med Sup Letter Automation',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.Medsup,
        exposedModule: './Module'
      }).then((m) => m.MedSupModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'macro',
    title: 'Macro Automation',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.macro,
        exposedModule: './Module'
      }).then((m) => m.MacroAutomationModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'PCP',
    title: 'PCP Form',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: environment.mfe.PCP,
        exposedModule: './Module'
      }).then((m) => m.PcpModule),
    canActivate: [AuthGuard]
  }
];
