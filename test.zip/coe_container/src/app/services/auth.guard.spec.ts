import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router, RouterStateSnapshot } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { BehaviorSubject } from 'rxjs';

import { AuthGuard } from './auth.guard';
import { AuthService } from './auth.service';

describe('AuthGuard', () => {
  let authGuard: AuthGuard;
  let routerSpy: any;
  let authServiceSpy: any;
  let mockRoute: any;


  beforeEach(() => {
    routerSpy = jasmine.createSpyObj('Router', ['navigate']);
    TestBed.configureTestingModule({
      imports:[RouterTestingModule,HttpClientTestingModule],
      providers: [AuthGuard, { provide: Router, useValue: routerSpy }]
    });
    authGuard = TestBed.inject(AuthGuard);
  });

  beforeEach(() => {
    authGuard = TestBed.inject(AuthGuard);
    authServiceSpy=TestBed.inject(AuthService);
    mockRoute={data:{roles:[1,2]}}
  });

  it('should be created', () => {
    expect(authGuard).toBeTruthy();
  });

  it('should be able to hit route when user is logged in', () => {
    let mockIsLoggedIn = new BehaviorSubject<boolean>(true);
    const currentUserSpy=spyOnProperty(authServiceSpy,'isLoggedIn',"get");
    currentUserSpy.and.returnValue(mockIsLoggedIn.asObservable());
    const result = authGuard.canActivate(mockRoute, <RouterStateSnapshot>{url: '/dashboard'});
    result.subscribe((res) => {
      expect(res).toEqual(true);
    })
  });

  it('should not be able to hit route when user is not logged in', () => {
    let mockIsLoggedIn = new BehaviorSubject<boolean>(false);
    const currentUserSpy=spyOnProperty(authServiceSpy,'isLoggedIn',"get");
    currentUserSpy.and.returnValue(mockIsLoggedIn.asObservable());
    const result = authGuard.canActivate(mockRoute, <RouterStateSnapshot>{url: '/dashboard'});
    result.subscribe((res) => {
      expect(routerSpy.navigate).toHaveBeenCalledWith(['/login']);
      expect(res).toEqual(false);
    })
  });
});