import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

import { BehaviorSubject, catchError, map, Observable, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loggedIn = new BehaviorSubject<boolean>(false);
  private apiAddress = environment.serverUrl;

  private role = new BehaviorSubject<any>('');
  userRoleSubject:Observable<any> = this.role.asObservable();

  constructor(private router: Router, private http: HttpClient) {}

  public get isLoggedIn() {
    return this.loggedIn.asObservable();
  }
  public setUserRole(val: any){
    this.role.next(val);
  }
  login(data: { user_id: any; password?: any }) {
    return this.http.post(this.apiAddress + 'bot_marketplace/login/', data).pipe(
      map((response) => {
        this.loggedIn.next(true);
        return response;
      }),
      catchError((err) => throwError(err))
    );
  }

  logout() {
    this.loggedIn.next(false);
    // this.router.navigate(['/login']);
  }
}
