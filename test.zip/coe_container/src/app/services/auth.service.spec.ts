import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { environment } from 'src/environments/environment';

import { AuthService } from './auth.service';

describe('AuthService', () => {
  let service: AuthService;
  let routerSpy: Router;
  let authService:any;  
  let httpMock:HttpTestingController;
  let api:string=environment.serverUrl;

  beforeEach(() => {
    routerSpy=jasmine.createSpyObj('Router',['navigate']);
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule, RouterTestingModule ],
      providers: [ AuthService, {provide:Router,useValue:routerSpy} ]
    });
    service = TestBed.inject(AuthService);
  });

  beforeEach(() => {
    authService= TestBed.inject(AuthService);
    httpMock=TestBed.inject(HttpTestingController);
    });

  it('should be created', () => {
    const service: AuthService = TestBed.inject(AuthService);
    expect(service).toBeTruthy();
  });

  it('#login() should call POST, set isLoggedIn to true and returned Observable should match the right data', () => {
    const mockToken = {
      token: 'wefrgt5yji8uyeet4hjiilp2jkilo89l76',
      username:'user',
      mail:'user@mail.com',
      role:2
    };
    authService.login({})
      .subscribe((Data: any) => {
        expect(Data.token).toEqual('wefrgt5yji8uyeet4hjiilp2jkilo89l76');
      });
    const req = httpMock.expectOne(api+'/bot_marketplace/login/');
    expect(req.request.method).toEqual('POST');
    req.flush(mockToken);
    authService.isLoggedIn.subscribe((res: boolean) => {
      expect(res).toBeTruthy();
    })
  });

  fit('#login should handle error',()=>{
    const err=new HttpErrorResponse({error:{msg:'something went wrong'},status:400})
    authService.login({}).subscribe(null,(thrownError:HttpErrorResponse)=>{
      expect(thrownError).toEqual(err);
    })
    const req = httpMock.expectOne(api+'/bot_marketplace/login/');
    expect(req.request.method).toEqual('POST');
    req.flush(err);
  })

  it('logout should remove user, set loggedIn to false and navigate to login',()=>{
    authService.logout();
    authService.isLoggedIn.subscribe((res: boolean) => {
      expect(res).toBeFalse();
    })
    expect(routerSpy.navigate).toHaveBeenCalledWith(['/login'])
  })

});
