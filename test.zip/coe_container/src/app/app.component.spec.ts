import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BehaviorSubject } from 'rxjs';
import { AppComponent } from './app.component';
import { NavSidebarComponent } from './components/nav-sidebar/nav-sidebar.component';
import { AuthService } from './services/auth.service';

describe('AppComponent', () => {

  let val = new BehaviorSubject<boolean>(true);
  let authSpyService = jasmine.createSpyObj('AuthService', ['login']); // set isLoggedIn to true
  authSpyService.isLoggedIn = val;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ RouterTestingModule, HttpClientTestingModule ],
      declarations: [ AppComponent, NavSidebarComponent ],
      providers: [ {provide: AuthService, useValue: authSpyService} ]
    }).compileComponents();
    
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should set isLoggedIn observable to true if user is logged in and show nav sidebar', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    let sidebar = fixture.debugElement.nativeElement.querySelector('div');
    expect(app.isLoggedIn$).toBeUndefined();
    expect(sidebar).toBeNull();
    app.ngOnInit();
    fixture.detectChanges();
    sidebar = fixture.debugElement.nativeElement.querySelector('div');
    expect(sidebar).toBeDefined();
    app.isLoggedIn$.subscribe((res) => {
      expect(res).toBeTrue();
    })
  })

  it('should set isLoggedIn observable to false if user is not logged in and should not show nav sidebar', () => {
    let val = new BehaviorSubject<boolean>(false);
    authSpyService.isLoggedIn = val;
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    let sidebar = fixture.debugElement.nativeElement.querySelector('div');
    expect(app.isLoggedIn$).toBeUndefined();
    expect(sidebar).toBeNull();
    app.ngOnInit();
    fixture.detectChanges();
    sidebar = fixture.debugElement.nativeElement.querySelector('div');
    app.isLoggedIn$.subscribe((res) => {
      expect(res).toBeFalse();
    })
  })
});