export const environment = {
  production: true,
  mfe: {
    dashboard: 'http://va33dlvjre309:4201/remoteEntry.js',
    myApps: 'http://va33dlvjre309:4202/remoteEntry.js',
    ltss: 'http://va33dlvjre309:4203/remoteEntry.js',
    jcode: 'http://va33dlvjre309:4204/remoteEntry.js',
    mmcp: 'http://va33dlvjre309:4205/remoteEntry.js',
    oca: 'http://va33dlvjre309:4206/remoteEntry.js',
    ib: 'http://va33dlvjre309:4207/remoteEntry.js',
    uatAutomation: 'http://va33dlvjre309:4208/remoteEntry.js',
    ash: 'http://va33dlvjre309:4209/remoteEntry.js',
    myRuns: 'http://va33dlvjre309:4210/remoteEntry.js',
    botAssignment: 'http://va33dlvjre309:4211/remoteEntry.js',
    kcua: 'http://va33dlvjre309:4212/remoteEntry.js',
    // dce: 'http://va33dlvjre309:4213/remoteEntry.js',
    // repairManagement: 'http://va33dlvjre309:4214/remoteEntry.js',
    // eca: 'http://va33dlvjre309:4215/remoteEntry.js',
    cc: 'http://va33dlvjre309:4217/remoteEntry.js'
  },
  serverUrl: 'http://va33dlvjre309:8000/'
};
