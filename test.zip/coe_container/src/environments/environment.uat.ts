// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  mfe: {
    dashboard: 'http://va33tlvjre407:4201/remoteEntry.js',
    myApps: 'http://va33tlvjre407:4202/remoteEntry.js',
    ltss: 'http://va33tlvjre407:4203/remoteEntry.js',
    jcode: 'http://va33tlvjre407:4204/remoteEntry.js',
    mmcp: 'http://va33tlvjre407:4205/remoteEntry.js',
    oca: 'http://va33tlvjre407:4206/remoteEntry.js',
    ib: 'http://va33tlvjre407:4207/remoteEntry.js',
    uatAutomation: 'http://va33tlvjre407:4208/remoteEntry.js',
    ash: 'http://va33tlvjre407:4209/remoteEntry.js',
    myRuns: 'http://va33tlvjre407:4210/remoteEntry.js',
    botAssignment: 'http://va33tlvjre407:4211/remoteEntry.js',
    kcua: 'http://va33tlvjre407:4212/remoteEntry.js',
    dce: 'http://va33tlvjre407:4213/remoteEntry.js',
    repairManagement: 'http://va33tlvjre407:4214/remoteEntry.js',
    eca: 'http://va33tlvjre407:4215/remoteEntry.js',
    // its: 'http://va33tlvjre407:4216/remoteEntry.js',
    cc: 'http://va33tlvjre407:4217/remoteEntry.js',
    Medsup: 'http://va33tlvjre407:4218/remoteEntry.js',
    macro: 'http://va33tlvjre407:4220/remoteEntry.js',
    its: 'http://va33tlvjre407:4221/remoteEntry.js'
  },
  serverUrl: 'http://va33tlvjre407:8000/'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
