// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  mfe: {
    dashboard: 'http://localhost:4201/remoteEntry.js',
    myApps: 'http://localhost:4202/remoteEntry.js',
    ltss: 'http://localhost:4203/remoteEntry.js',
    jcode: 'http://localhost:4204/remoteEntry.js',
    mmcp: 'http://localhost:4205/remoteEntry.js',
    oca: 'http://localhost:4206/remoteEntry.js',
    ib: 'http://localhost:4207/remoteEntry.js',
    uatAutomation: 'http://localhost:4208/remoteEntry.js',
    ash: 'http://localhost:4209/remoteEntry.js',
    myRuns: 'http://localhost:4210/remoteEntry.js',
    botAssignment: 'http://localhost:4211/remoteEntry.js',
    kcua: 'http://localhost:4212/remoteEntry.js',
    dce: 'http://localhost:4213/remoteEntry.js',
    repairManagement: 'http://localhost:4214/remoteEntry.js',
    eca: 'http://localhost:4215/remoteEntry.js',
    // its: 'http://localhost:4216/remoteEntry.js',
    cc: 'http://localhost:4217/remoteEntry.js',
    Medsup: 'http://localhost:4218/remoteEntry.js',
    macro: 'http://localhost:4220/remoteEntry.js'
  },
  serverUrl: 'http://va33dlvjre309:8000/'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
