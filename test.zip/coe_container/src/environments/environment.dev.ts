// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  mfe: {
    dashboard: 'http://va33dlvjre309:4201/remoteEntry.js',
    myApps: 'http://va33dlvjre309:4202/remoteEntry.js',
    ltss: 'http://va33dlvjre309:4203/remoteEntry.js',
    jcode: 'http://va33dlvjre309:4204/remoteEntry.js',
    mmcp: 'http://va33dlvjre309:4205/remoteEntry.js',
    oca: 'http://va33dlvjre309:4206/remoteEntry.js',
    ib: 'http://va33dlvjre309:4207/remoteEntry.js',
    uatAutomation: 'http://va33dlvjre309:4208/remoteEntry.js',
    ash: 'http://va33dlvjre309:4209/remoteEntry.js',
    myRuns: 'http://va33dlvjre309:4210/remoteEntry.js',
    botAssignment: 'http://va33dlvjre309:4211/remoteEntry.js',
    kcua: 'http://va33dlvjre309:4212/remoteEntry.js',
    dce: 'http://va33dlvjre309:4213/remoteEntry.js',
    repairManagement: 'http://va33dlvjre309:4214/remoteEntry.js',
    eca: 'http://va33dlvjre309:4215/remoteEntry.js',
    // its: 'http://va33dlvjre309:4216/remoteEntry.js',
    cc: 'http://va33dlvjre309:4217/remoteEntry.js',
    Medsup: 'http://va33dlvjre309:4218/remoteEntry.js',
    macro: 'http://va33dlvjre309:4220/remoteEntry.js',
    PCP: 'http://va33dlvjre309:4221/remoteEntry.js'
  },
  serverUrl: 'http://va33dlvjre309:8000/'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
