import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PcpReviewComponent } from './review.component';

describe('PcpReviewComponent', () => {
  let component: PcpReviewComponent;
  let fixture: ComponentFixture<PcpReviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PcpReviewComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(PcpReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
