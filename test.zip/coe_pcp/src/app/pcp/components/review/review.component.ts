import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { PdfViewerComponent } from 'ng2-pdf-viewer';
import { PDFDocumentProxy } from 'ng2-pdf-viewer/node_modules/pdfjs-dist/types/src/display/api';

import { MessageService } from 'primeng/api';
import { PcpApiService } from '../../services/pcp-api.service';
import { PcpSharedService } from '../../services/pcp-shared.service';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class PcpReviewComponent implements OnInit {
  Docsrc!: string;
  @Input() selectedfile: any;
  pdfSrc = "";
  totalPages = 0;
  rotation = 0;
  _pdfPage = 1;
  zoom: number = 1;
  renderTextMode = 1;
  @ViewChild(PdfViewerComponent, { static: false }) pdfViewComponent: ElementRef<HTMLElement>;
  private pdfComponent!: PdfViewerComponent;
  pdf: any;
  scrollNum = 1;
  pageElements: any = [];
  extractedData: any;
  updateFlag: boolean = false;

  fileReview: boolean;
  pid: any;
  updatedData: any;
  downloadData: any;
  constructor(
    private pcpApiService: PcpApiService,
    private pcpSharedService: PcpSharedService,
    private messageService: MessageService
  ) {
    this.pcpSharedService.fileReviewSubject.subscribe((x) => (this.fileReview = x));
    this.pcpSharedService.filePidSubject.subscribe((pid) => (this.pid = pid))
  }
  afterLoadComplete(pdf: PDFDocumentProxy) {
    console.log(pdf, "pdf", pdf._pdfInfo.numPages);

    this.pdf = pdf;
    this.totalPages = pdf._pdfInfo.numPages;
  }
  pageRendered(event: any) { }

  get pdfPage(): number {
    return this._pdfPage;
  }
  @Input() set pdfPage(page: number) {
    this._pdfPage = page;
    this.scrollNum = page;
  }
  incrementPage(count: number) {
    if (this.pdfPage + count > 0 && this.pdfPage + count <= this.totalPages) {
      this.pdfPage += count;
    }
  }

  rotatePdf(value: any) {
    if (value == 1) {
      this.rotation += 90;
    } else {
      this.rotation -= 90;
    }
  }
  opennewtab(pdfSrc) { window.open(pdfSrc, "_blank") }
  zoomIn() { this.zoom += 0.25 }
  zoomOut() {
    if (this.zoom > 0.25) this.zoom -= 0.25
  }
  Reset() { this.zoom = 1 }
  ngOnInit(): void {

    let reviewfile = {
      "pid": this.selectedfile.pid,
      "filename": this.selectedfile.filename
    }
    this.pcpApiService.getData(reviewfile).subscribe({
      next: (data: any) => {
        console.log(data, "res data");
        this.extractedData = data.extracted_data;
        console.log(this.extractedData);
        this.pdfSrc = "assets/Anthem - Albert Gallagher.pdf";
      },
      error: (err: any) => {
        console.log('error', err);
        this.pcpSharedService.setLoading(false);
        this.messageService.add({ sticky: true, severity: 'error', summary: 'something went wrong' });
      }
    });
    console.log(this.pdfSrc);
    // this.extractedData = [{
    //   "label1": "value1",
    //   "label2": "value2",
    //   "label3": "value3",
    //   "label4": "value4"
    // }]

  }
  checkValue(updateVal) {
    console.log(updateVal);
    this.updateFlag = updateVal;
    let inputFields = document.getElementsByClassName('form-control');
    for (let i = 0; i < inputFields.length; i++) {
      if (updateVal) {
        inputFields[i].setAttribute('readonly', 'true');
      } else {
        inputFields[i].removeAttribute('readonly');
      }
    }

  }
  changeinFields(keyname, e) {
    console.log(keyname, e);
    Object.entries(this.extractedData).forEach(([key, value]) => {
      if (key == keyname) {
        console.log(key, value, this.extractedData[key]);
        this.extractedData[key] = e;
      }
    })
    console.log(this.extractedData, "edited data");
  }
  update() {
    console.log(this.selectedfile, "selectedfile");
    console.log(this.extractedData, "this.extractedData", this.updateFlag);
    let inputData = {
      "pid": this.pid,
      "filename": this.selectedfile.filename,
      "update_flag": this.updateFlag,
      "extracted_data": this.extractedData
    }
    console.log(inputData, "inputData");
    this.pcpApiService.updateData(inputData).subscribe({
      next: (data: any) => {
        console.log(data, "data");
        this.updatedData = data.file_path;
        this.fileReview = false;
        this.downloadData = this.updatedData.every((val, i) => val.status === 'Review Successful')
        console.log(this.downloadData, "download data boolean", this.updatedData.every((val, i) => val.status === 'Review Successful'));
        this.pcpSharedService.setdownloadDataBoolean(this.downloadData)
        this.pcpSharedService.setdataUpdate(this.updatedData);
        this.pcpSharedService.setfileReview(this.fileReview)
      },
      error: (err: any) => {
        console.log('error', err);
        this.pcpSharedService.setLoading(false);
        this.messageService.add({ sticky: true, severity: 'error', summary: 'something went wrong' });
      }
    });


  }
  cancel() {
    this.fileReview = false;
    this.pcpSharedService.setfileReview(this.fileReview)
  }

}
