import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MessageService } from 'primeng/api';
import { PcpApiService } from '../../services/pcp-api.service';
import { PcpSharedService } from '../../services/pcp-shared.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class PcpUploadComponent implements OnInit {
  loading: boolean = false;
  files: any[] = [];
  showUploadStatus: boolean = false;
  uploaded: boolean = false;
  filename = '';
  @Output() sendData = new EventEmitter<any>();
  pid: any;
  dialog: boolean = false;
  review: boolean = false;
  fileReview: boolean = false;
  selectedfile: any = [];
  reviewMsg: boolean = false;
  fileList: any[];
  updatedData: any = [];
  downloadData: boolean = false;
  downloadedData: any;
  finalData: any = [];
  emptyFiles: any = false;
  _validFileExtensions = [".jpg", ".jpeg", ".bmp", ".gif", ".png"];

  constructor(
    private pcpApiService: PcpApiService,
    private pcpSharedService: PcpSharedService,
    private messageService: MessageService
  ) {
    this.pcpSharedService.loading.subscribe((x) => (this.loading = x));
    this.pcpSharedService.fileReviewSubject.subscribe((val) => (this.fileReview = val));
    this.pcpSharedService.reviewBooleanSubject.subscribe((val) => { this.review = val; })
    this.pcpSharedService.uploadStatusSubject.subscribe((val) => this.showUploadStatus = val)
    this.pcpSharedService.filesArrSubject.subscribe((val) => {
      this.emptyFiles = val;
      if (this.emptyFiles) {
        this.files = [];
      }
    })
    this.pcpSharedService.dataUpdateSubject.subscribe((val) => {
      console.log(this.updatedData, "updated data");

      this.updatedData = val;
      for (let i = 0; i < this.files.length; i++) {
        console.log(this.files[i].filename, this.updatedData[0].filename, this.files[i].status);
        if (this.files[i].filename == this.updatedData[i].filename) {
          this.files[i].status = this.updatedData[i].status;
        }
      }

      console.log(this.files, this.updatedData, "updated data", this.downloadData);

    });
    this.pcpSharedService.downloadBooleanSubject.subscribe((val) => {
      console.log(val, "download boolean");
      this.downloadData = val;
    });
  }

  ngOnInit(): void { }

  /**
   * on file drop handler
   */
  onFileDropped($event: any) {
    console.log($event, "on file dropped event");

    this.prepareFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler($event: any) {
    console.log("event", $event.target.files, $event.target.files.length)
    if ($event.target.files.length > 5) {
      alert("Maximum 5 files are allowed");
    } else {
      this.prepareFilesList($event.target.files);
    }
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    this.fileList = files;
    for (const item of files) {
      item.progress = 0;
      item.filename = item.name;
      item.status = 'File upload successful';
      this.files.push(item);
    }
    console.log(this.files);
    this.showUploadStatus = true;
    this.pcpSharedService.setUploadStatus(this.showUploadStatus);
    this.downloadData = false;
    this.updatedData = [];

  }

  deleteFile(filename: any) {
    let file = filename;
    let index = this.files.findIndex(
      (i: any) => i.name === file.name
    )
    if (index !== -1) {
      this.files.splice(
        index, 1
      );
    }

    if (this.files.length == 0) {
      this.showUploadStatus = false;
      this.pcpSharedService.setUploadStatus(this.showUploadStatus)
      this.review = false;
      this.pcpSharedService.setReview(this.review);
    }
  }

  runApp() {
    this.pcpSharedService.setLoading(true);
    let formdata = new FormData();
    for (let i = 0; i < this.fileList.length; i++) {
      formdata.append('pdf', this.fileList[i])
    }

    this.pcpApiService.runApp(formdata).subscribe({
      next: (data: any) => {
        this.pcpSharedService.setLoading(false);
        if (data.Success) {
          this.files = data.data;
          this.pid = data.pid;
          this.pcpSharedService.setPid(this.pid);
          this.review = true;
          this.pcpSharedService.setReview(this.review);
        } else {
          if (data.Message) {
            this.messageService.add({ sticky: true, severity: 'error', summary: data.Message });
          } else {
            this.messageService.add({ sticky: true, severity: 'error', summary: data.Error });
          }
        }
      },
      error: (err: any) => {
        this.pcpSharedService.setLoading(false);
        this.messageService.add({ sticky: true, severity: 'error', summary: 'something went wrong' });
      }
    });
  }

  reviewFile(filename: any) {
    filename.pid = this.pid;
    this.selectedfile = filename;
    this.fileReview = true;
    this.pcpSharedService.setfileReview(this.fileReview);
  }
  downloadFile() {
    let inputJson = {
      pid: this.pid
    }
    this.pcpApiService.downloadData(inputJson).subscribe({
      next: (data: any) => {
        this.pcpSharedService.setLoading(false);
        this.downloadedData = data;

        this.finalData = [];
        let sheetName = [];
        Object.entries(this.downloadedData).forEach(([key, value]) => {
          this.finalData.push(this.downloadedData[key]);
          sheetName.push(key);
        })
        let elem = [];
        sheetName.forEach((ele) => {
          elem.push(this.truncateChar(ele));
        })
        console.log(this.finalData, "finalData", sheetName, elem);
        this.excelDownload(this.finalData, elem);
      },
      error: (err: any) => {
        this.pcpSharedService.setLoading(false);
        this.messageService.add({ sticky: true, severity: 'error', summary: 'something went wrong' });
      }
    });
  }

  truncateChar(text: string): string {
    let charlimit = 28;
    if (!text || text.length <= charlimit) {
      return text;
    }

    let without_html = text.replace(/<(?:.|\n)*?>/gm, '');
    let shortened = without_html.substring(0, charlimit) + "...";
    return shortened;
  }
  excelDownload(finalArr, sheets) {
    import('xlsx').then((xlsx) => {
      const wb = xlsx.utils.book_new();

      for (var i = 0; i < sheets.length; i++) {
        var worksheet = xlsx.utils.json_to_sheet([finalArr[i]]);
        xlsx.utils.book_append_sheet(wb, worksheet, sheets[i]);
      }
      const excelBuffer: any = xlsx.write(wb, {
        bookType: 'xlsx',
        type: 'array',
      });
      this.pcpSharedService.saveAsExcelFile(excelBuffer, 'PCP_Consolidated_Report_' + new Date().getTime());
    });
  }

  // Validate(oForm) {
  //   var arrInputs = oForm.getElementsByTagName("input");
  //   for (var i = 0; i < arrInputs.length; i++) {
  //     var oInput = arrInputs[i];
  //     if (oInput.type == "file") {
  //       var sFileName = oInput.value;
  //       if (sFileName.length > 0) {
  //         var blnValid = false;
  //         for (var j = 0; j < this._validFileExtensions.length; j++) {
  //           var sCurExtension = this._validFileExtensions[j];
  //           if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
  //             blnValid = true;
  //             break;
  //           }
  //         }

  //         if (!blnValid) {
  //           alert("Sorry, " + sFileName + " is invalid, allowed extensions are: " + this._validFileExtensions.join(", "));
  //           return false;
  //         }
  //       }
  //     }
  //   }

  //   return true;
  // }
  // downloadSampleFile() {
  //   import('xlsx').then((xlsx) => {
  //     const worksheet = xlsx.utils.json_to_sheet([]);
  //     const workbook = { Sheets: { data: worksheet }, SheetNames: ['Paper CLaims', 'Edi Claims'] };
  //     const excelBuffer: any = xlsx.write(workbook, {
  //       bookType: 'xlsx',
  //       type: 'array'
  //     });
  //     this.pcpSharedService.saveAsExcelFile(excelBuffer, 'Pcp_claims_Samplefile');
  //   });
  // }
}
