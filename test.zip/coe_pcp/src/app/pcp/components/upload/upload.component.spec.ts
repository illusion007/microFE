import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AshUploadComponent } from './upload.component';

describe('AshUploadComponent', () => {
  let component: AshUploadComponent;
  let fixture: ComponentFixture<AshUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AshUploadComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AshUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
