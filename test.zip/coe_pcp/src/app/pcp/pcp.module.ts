import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PcpComponent } from './pcp.component';
import { PcpRoutingModule } from './pcp.routing.module';
import { HttpClientModule } from '@angular/common/http';
import { TableModule } from 'primeng/table';
// import { ProgressBarModule } from 'primeng/progressbar';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ButtonModule } from 'primeng/button';
import { MessagesModule } from 'primeng/messages';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { FormsModule } from '@angular/forms';
import { PcpUploadComponent } from './components/upload/upload.component';
import { PcpReviewComponent } from './components/review/review.component';

// import { AshRoutingModule } from './ash.routing.module';
// import { AshComponent } from './ash.component';
import { PcpApiService } from './services/pcp-api.service'
import { PcpSharedService } from './services/pcp-shared.service';

@NgModule({
  declarations: [PcpComponent, PcpUploadComponent, PcpReviewComponent],
  imports: [CommonModule, FormsModule, PcpRoutingModule,
    TableModule,
    ProgressSpinnerModule,
    ToastModule,
    ConfirmDialogModule,
    MessagesModule,
    ButtonModule,
    // ProgressBarModule,
    PdfViewerModule,
    HttpClientModule],
  providers: [
    MessageService,
    ConfirmationService,
    PcpApiService, PcpSharedService]
})
export class PcpModule { }
