import { TestBed } from '@angular/core/testing';

import { PcpSharedService } from './pcp-shared.service';

describe('PcpSharedService', () => {
  let service: PcpSharedService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PcpSharedService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
