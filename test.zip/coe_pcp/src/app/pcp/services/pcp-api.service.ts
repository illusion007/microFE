import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { of } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PcpApiService {
  agid = localStorage.getItem('agid') || '';
  url = environment.serverUrl + 'pcp_forms_app/runbot/';
  resulturl = environment.serverUrl + 'pcp_forms_app/review/';
  updateurl = environment.serverUrl + 'pcp_forms_app/update/';
  downloadUrl = environment.serverUrl + 'pcp_forms_app/download/';
  private key: string;
  private headers: HttpHeaders;

  constructor(private http: HttpClient) {
    this.key = '000102030405060708090a0b0c0d0e0f';
    const decrypted = CryptoJS.AES.decrypt(localStorage.getItem('token') || '', this.key).toString(CryptoJS.enc.Utf8);

    this.headers = new HttpHeaders().append('Authorization', JSON.parse(JSON.stringify(decrypted)));
  }

  runApp(data: any) {
    let params = new HttpParams();
    params = params.append('ag_id', this.agid);
    console.log(params, "params");
    return this.http.post(this.url, data, { headers: this.headers });
  }

  getData(inputJson: any) {
    return this.http.post(this.resulturl, inputJson, { headers: this.headers });
  }

  updateData(data: any) {
    return this.http.post(this.updateurl, data, { headers: this.headers });
  }
  downloadData(inputJson: any) {
    return this.http.post(this.downloadUrl, inputJson, { headers: this.headers });
  }
}
