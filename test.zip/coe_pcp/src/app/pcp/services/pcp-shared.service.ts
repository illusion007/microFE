import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { saveAs } from 'file-saver';

@Injectable({
  providedIn: 'root'
})
export class PcpSharedService {
  private loadingSubject: BehaviorSubject<boolean>;
  public loading: Observable<boolean>;

  public progressval = new BehaviorSubject<any>('');
  progressvalSubject: Observable<any> = this.progressval.asObservable();

  public fileReview = new BehaviorSubject<any>('');
  fileReviewSubject: Observable<any> = this.fileReview.asObservable();

  public filePid = new BehaviorSubject<any>('');
  filePidSubject = this.filePid.asObservable();

  public dataUpdate = new BehaviorSubject<any>('');
  dataUpdateSubject: Observable<any> = this.dataUpdate.asObservable();

  public downloadBoolean = new BehaviorSubject<any>('');
  downloadBooleanSubject: Observable<any> = this.downloadBoolean.asObservable();

  public reviewBoolean = new BehaviorSubject<any>('');
  reviewBooleanSubject: Observable<any> = this.reviewBoolean.asObservable();

  public uploadStatusBoolean = new BehaviorSubject<any>('');
  uploadStatusSubject: Observable<any> = this.uploadStatusBoolean.asObservable();

  public filesArr = new BehaviorSubject<any>('');
  filesArrSubject: Observable<any> = this.filesArr.asObservable();


  constructor() {
    this.loadingSubject = new BehaviorSubject<boolean>(false);
    this.loading = this.loadingSubject.asObservable();
  }
  public setLoading(val: boolean) {
    this.loadingSubject.next(val);
  }

  public setFilesData(val: any) {
    console.log(val, "val id");
    this.filesArr.next(val);
  }

  public setPid(val: any) {
    console.log(val, "val id");
    this.filePid.next(val);
  }

  public setdataUpdate(val: any) {
    console.log(val, "val id");
    this.dataUpdate.next(val);
  }

  public setdownloadDataBoolean(val: any) {
    this.downloadBoolean.next(val)
  }
  public setprogressval(val: any) {
    this.progressval.next(val);
  }
  public setfileReview(fileReviewval: any) {
    this.fileReview.next(fileReviewval);
  }

  public setReview(reviewVal: any) {
    this.reviewBoolean.next(reviewVal)
  }

  public setUploadStatus(uploadstatus: any) {
    this.uploadStatusBoolean.next(uploadstatus)
  }
  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE =
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE,
    });
    saveAs(
      data,
      fileName + EXCEL_EXTENSION
    );
  }
}
