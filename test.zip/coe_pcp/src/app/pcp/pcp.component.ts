
import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { PcpSharedService } from './services/pcp-shared.service';

@Component({
  selector: 'app-pcp',
  templateUrl: './pcp.component.html',
  styleUrls: ['./pcp.component.css']
})
export class PcpComponent implements OnInit {

  loading: boolean = false;
  fileReview: boolean = false;
  showUploadStatus: boolean = false;
  review: boolean = false;
  emptyFiles: boolean = false;
  constructor(private PcpSharedService: PcpSharedService, private location: Location) {
    this.PcpSharedService.loading.subscribe((x) => (this.loading = x));
    this.PcpSharedService.fileReviewSubject.subscribe((val) => { this.fileReview = val; })
    this.PcpSharedService.reviewBooleanSubject.subscribe((val) => { this.review = val; })
    this.PcpSharedService.uploadStatusSubject.subscribe((val) => this.showUploadStatus = val)
  }

  hadData: boolean = false;
  files: any[] = [];
  app = {
    appname: 'PCP Form',
    app_description: 'Automate reviewing attachment to ensure fields are populated appropriately.Automate reviewing attachment to ensure fields are populated appropriately.Automate reviewing attachment to ensure fields are populated appropriately.',
    app_health: true,
    accuracy: '98%',
    downtime: "30 sec.",
    runs_in_progress: 2
  };

  ngOnInit(): void {
    console.log('In PCP form component file');
    this.fileReview = false;
    this.showUploadStatus = false;
    this.review = false;
    this.emptyFiles = true;
    this.PcpSharedService.setFilesData(this.emptyFiles);
    this.PcpSharedService.setfileReview(this.fileReview);
    this.PcpSharedService.setUploadStatus(this.showUploadStatus);
    this.PcpSharedService.setReview(this.review);

  }

  navigateToMyApps() {
    this.location.back();
  }

  runAppAgain() {
    this.fileReview = false;
    this.showUploadStatus = false;
    this.review = false;
    this.emptyFiles = true;
    this.PcpSharedService.setFilesData(this.emptyFiles);
    this.PcpSharedService.setfileReview(this.fileReview);
    this.PcpSharedService.setUploadStatus(this.showUploadStatus);
    this.PcpSharedService.setReview(this.review);
  }
}
