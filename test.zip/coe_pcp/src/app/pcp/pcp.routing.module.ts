import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PcpComponent } from './pcp.component';

const routes: Routes = [{ path: '', component: PcpComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PcpRoutingModule {}
