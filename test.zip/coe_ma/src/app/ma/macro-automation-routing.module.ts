import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MacroAutomationComponent } from './macro-automation.component';

const routes: Routes = [{ path: '', component: MacroAutomationComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MacroAutomationRoutingModule { }
