import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { MessageService } from 'primeng/api';
import { HttpErrorResponse } from '@angular/common/http';

import { MacroApiServiceService } from './services/macro-api-service.service';
import { MacroSharedServiceService } from './services/macro-shared-service.service';

@Component({
  selector: 'app-macro-automation',
  templateUrl: './macro-automation.component.html',
  styleUrls: ['./macro-automation.component.css']
})
export class MacroAutomationComponent implements OnInit {
  isAvailable = false;
  isBtn :boolean =false;
  running =false;
  available =false;
  runningData: any = [];
  availableData: any = [];
  availableVdaas: any;
  runningVdaas: any;
  vdata: any = [];
  loading: boolean = false;
      
   //runningData=[{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Running","user":"Al22222"}];
  //availableData=[{"hostname":"VDaas123","timestamp":"2:33","status":"Available","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Available","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Available","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Available","user":"Al22222"},{"hostname":"VDaas123","timestamp":"2:33","status":"Available","user":"Al22222"}];
  constructor(private location: Location,
              private messageService: MessageService,
              private macroApiService : MacroApiServiceService,
              private macroSharedService : MacroSharedServiceService,) {}

  ngOnInit(): void {
    this.macroSharedService.getLoading().subscribe((val) => (this.loading = val));
    this.vdaasData();       
  }

   /**
    * @method vdaassData 
    * @description fetch data for available/running servers.
    */ 
  vdaasData(){
    this.macroSharedService.setLoading(true);
      this.macroApiService.getVdaasData().subscribe({
        next: (res: any) => {
          this.macroSharedService.setLoading(false);
          if (res && res.length >= 0) {
            this.isBtn =true;
            this.vdata = res;
            for (let i = 0; i < this.vdata.length; i++) {
                let item = this.vdata.find((data:any) => data.status == "UnAvailable");
                  if (item) {
                    item.status = "Running";
                  } 
                }
              this.runningData = this.vdata.filter((data:any) => data.status !== "Available");
              if (this.runningData === undefined || this.runningData.length == 0) {
                this.running=true;
                this.runningVdaas= 0;
              }else {
                this.running = false;
                this.runningVdaas = JSON.parse(JSON.stringify(this.runningData)).length;
              }
              this.availableData = this.vdata.filter((data:any) => data.status !== "Running");
              if (this.availableData === undefined || this.availableData.length == 0) {
                this.available=true;
                this.availableVdaas= 0;
              }else {
                this.available = false;
                this.availableVdaas = JSON.parse(JSON.stringify(this.availableData)).length;
              }
          } else {
            this.messageService.add({ sticky: true, severity: 'error', summary: res.Message });
          }
        },
        error: (err: any) => {
          this.isAvailable = true;
          this.macroSharedService.setLoading(false);
          this.messageService.add({ sticky: true, severity: 'error', summary: 'something went wrong' });
        }
      });
    }
  /**
   * @method navigateToMyApps
   * @description navigate back to Apps screen.
   */
  navigateToMyApps() {
    this.location.back();
  }

  /**
    * @method exportExcel
   * @description Download csv file.
   */
  exportExcel() {
    import('xlsx').then((xlsx) => {
      const worksheet = xlsx.utils.json_to_sheet(this.vdata);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = xlsx.write(workbook, {
        bookType: 'xlsx',
        type: 'array',
      });
      this.macroSharedService.saveAsExcelFile(excelBuffer, 'macro_vm_report_' + new Date().getTime());
    });
  }

  /**
   * @method refresh
   * @description reload the Vdass API
   */
  refresh(){
    this.ngOnInit();
  }
}
