import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MacroAutomationComponent } from './macro-automation.component';

describe('MacroAutomationComponent', () => {
  let component: MacroAutomationComponent;
  let fixture: ComponentFixture<MacroAutomationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MacroAutomationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MacroAutomationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
