import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { of } from 'rxjs';
import * as CryptoJS from 'crypto-js';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MacroApiServiceService {
  url = environment.serverUrl + 'macro_automation_app/dashboard/';
  private key: string;
  private headers: HttpHeaders;

  constructor(private http: HttpClient) {
    this.key = '000102030405060708090a0b0c0d0e0f';
    const decrypted = CryptoJS.AES.decrypt(localStorage.getItem('token') || '', this.key).toString(CryptoJS.enc.Utf8);
    this.headers = new HttpHeaders().append('Authorization', JSON.parse(JSON.stringify(decrypted)));
  }

  getVdaasData() {
    return this.http.get(`${this.url}`, { headers: this.headers });
  }
}
