import { TestBed } from '@angular/core/testing';

import { MacroSharedServiceService } from './macro-shared-service.service';

describe('MacroSharedServiceService', () => {
  let service: MacroSharedServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MacroSharedServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
