import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { saveAs } from 'file-saver';

@Injectable({
  providedIn: 'root'
})
export class MacroSharedServiceService {

  private loadingSubject: BehaviorSubject<boolean>;

  constructor() {
    this.loadingSubject = new BehaviorSubject<boolean>(false);
  }

  /**
   * @method setLoading
   * @param val 
   */
  public setLoading(val: boolean) {
    this.loadingSubject.next(val);
  }

  /**
   * @method getLoading
   * @returns 
   */
  public getLoading() {
    return this.loadingSubject.asObservable();
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE =
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE,
    });
    saveAs(
      data,
      fileName + EXCEL_EXTENSION
    );
  }
}
