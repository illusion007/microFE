import { TestBed } from '@angular/core/testing';

import { MacroApiServiceService } from './macro-api-service.service';

describe('MacroApiServiceService', () => {
  let service: MacroApiServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MacroApiServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
