import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MessageService } from 'primeng/api';
import { HttpClientModule } from '@angular/common/http';

import { MacroAutomationRoutingModule } from './macro-automation-routing.module';
import { MacroAutomationComponent } from './macro-automation.component';

import { DividerModule } from 'primeng/divider';
import { CardModule } from 'primeng/card';
import { ImageModule } from 'primeng/image';
import { ChipModule } from 'primeng/chip';
import { ButtonModule } from 'primeng/button';
import { ProgressSpinnerModule } from 'primeng/progressspinner'

@NgModule({
  declarations: [MacroAutomationComponent],
  imports: [CommonModule,HttpClientModule,ButtonModule,DividerModule,CardModule,ChipModule,ImageModule,ProgressSpinnerModule,MacroAutomationRoutingModule],
  providers: [MessageService]
})
export class MacroAutomationModule { }
